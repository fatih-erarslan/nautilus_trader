//! Evolution engine for parasitic organisms

use std::sync::Arc;
use dashmap::DashMap;
use uuid::Uuid;
use serde::{Serialize, Deserialize};
use chrono::{DateTime, Utc, Duration};
use rand::{Rng, seq::SliceRandom};
use tokio::sync::RwLock;

use crate::{
    organisms::{ParasiticOrganism, OrganismGenetics, AdaptationFeedback, MarketConditions},
    ParasiticConfig
};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EvolutionStatus {
    pub current_generation: u64,
    pub total_organisms: usize,
    pub average_fitness: f64,
    pub best_fitness: f64,
    pub worst_fitness: f64,
    pub fitness_variance: f64,
    pub genetic_diversity: f64,
    pub last_evolution: DateTime<Utc>,
    pub next_evolution: DateTime<Utc>,
    pub mutations_this_cycle: u64,
    pub crossovers_this_cycle: u64,
    pub terminations_this_cycle: u64,
    pub new_spawns_this_cycle: u64,
    pub selection_pressure: f64,
    pub environmental_stress: f64,
    pub population_health: EvolutionHealth,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EvolutionHealth {
    pub stability: f64,
    pub adaptability: f64,
    pub sustainability: f64,
    pub resilience: f64,
}

/// Selection strategy for evolution
#[derive(Debug, Clone)]
pub enum SelectionStrategy {
    Tournament { size: usize },
    Roulette,
    Elite { percentage: f64 },
    Hybrid { primary: Box<SelectionStrategy>, secondary: Box<SelectionStrategy> },
}

/// Genetic algorithm parameters
#[derive(Debug, Clone)]
pub struct GeneticAlgorithmConfig {
    pub population_size: usize,
    pub elite_percentage: f64,
    pub mutation_rate: f64,
    pub crossover_rate: f64,
    pub selection_pressure: f64,
    pub diversity_threshold: f64,
    pub max_generations_without_improvement: u32,
}

pub struct EvolutionEngine {
    config: ParasiticConfig,
    genetic_config: GeneticAlgorithmConfig,
    current_generation: u64,
    last_evolution: DateTime<Utc>,
    evolution_history: Vec<EvolutionStatus>,
    selection_strategy: SelectionStrategy,
    fitness_history: Arc<RwLock<Vec<Vec<f64>>>>,
    mutation_count: u64,
    crossover_count: u64,
    termination_count: u64,
    spawn_count: u64,
}

impl EvolutionEngine {
    pub fn new(config: &ParasiticConfig) -> Self {
        let genetic_config = GeneticAlgorithmConfig {
            population_size: 100,
            elite_percentage: 0.1,
            mutation_rate: config.mutation_rate,
            crossover_rate: 0.8,
            selection_pressure: 1.2,
            diversity_threshold: 0.1,
            max_generations_without_improvement: 20,
        };
        
        let selection_strategy = SelectionStrategy::Hybrid {
            primary: Box::new(SelectionStrategy::Elite { percentage: 0.2 }),
            secondary: Box::new(SelectionStrategy::Tournament { size: 5 }),
        };
        
        Self {
            config: config.clone(),
            genetic_config,
            current_generation: 0,
            last_evolution: Utc::now(),
            evolution_history: Vec::new(),
            selection_strategy,
            fitness_history: Arc::new(RwLock::new(Vec::new())),
            mutation_count: 0,
            crossover_count: 0,
            termination_count: 0,
            spawn_count: 0,
        }
    }
    
    pub async fn evolve_organisms(
        &mut self,
        organisms: &Arc<DashMap<Uuid, Box<dyn ParasiticOrganism + Send + Sync>>>,
    ) -> Result<EvolutionStatus, Box<dyn std::error::Error + Send + Sync>> {
        let start_time = std::time::Instant::now();
        
        // Reset cycle counters
        self.mutation_count = 0;
        self.crossover_count = 0;
        self.termination_count = 0;
        self.spawn_count = 0;
        
        // Collect current population metrics
        let fitness_scores = self.collect_fitness_scores(organisms).await;
        let population_size = fitness_scores.len();
        
        if population_size == 0 {
            return Err("No organisms available for evolution".into());
        }
        
        // Calculate population statistics
        let stats = self.calculate_population_stats(&fitness_scores).await;
        
        // Store fitness history
        {
            let mut history = self.fitness_history.write().await;
            let current_fitnesses: Vec<f64> = fitness_scores.iter().map(|(_, f)| *f).collect();
            history.push(current_fitnesses);
            
            // Keep only last 100 generations
            if history.len() > 100 {
                history.remove(0);
            }
        }
        
        // Determine if evolution pressure should be applied
        let environmental_stress = self.calculate_environmental_stress(&stats).await;
        let should_evolve = self.should_trigger_evolution(&stats, environmental_stress).await;
        
        if should_evolve {
            // Selection phase
            let selected_organisms = self.selection_phase(organisms, &fitness_scores).await?;
            
            // Reproduction phase (crossover + mutation)
            self.reproduction_phase(organisms, &selected_organisms).await?;
            
            // Elimination phase
            self.elimination_phase(organisms, &fitness_scores).await?;
            
            // Population maintenance
            self.maintain_population(organisms).await?;
            
            self.current_generation += 1;
        }
        
        // Update evolution timestamp
        self.last_evolution = Utc::now();
        
        // Create evolution status
        let status = self.create_evolution_status(organisms, environmental_stress).await;
        self.evolution_history.push(status.clone());
        
        // Keep only last 50 evolution records
        if self.evolution_history.len() > 50 {
            self.evolution_history.remove(0);
        }
        
        tracing::info!(
            "Evolution cycle {} completed in {:?}ms - {} organisms, avg fitness: {:.3}, diversity: {:.3}",
            self.current_generation,
            start_time.elapsed().as_millis(),
            status.total_organisms,
            status.average_fitness,
            status.genetic_diversity
        );
        
        Ok(status)
    }
    
    pub async fn get_status(&self, organisms: &Arc<DashMap<Uuid, Box<dyn ParasiticOrganism + Send + Sync>>>) -> EvolutionStatus {
        if let Some(latest_status) = self.evolution_history.last() {
            latest_status.clone()
        } else {
            // Generate status on-demand if no history exists
            let fitness_scores = self.collect_fitness_scores(organisms).await;
            let stats = self.calculate_population_stats(&fitness_scores).await;
            let genetic_diversity = self.calculate_genetic_diversity(organisms).await;
            let environmental_stress = self.calculate_environmental_stress(&stats).await;
            
            EvolutionStatus {
                current_generation: self.current_generation,
                total_organisms: fitness_scores.len(),
                average_fitness: stats.average_fitness,
                best_fitness: stats.best_fitness,
                worst_fitness: stats.worst_fitness,
                fitness_variance: stats.fitness_variance,
                genetic_diversity,
                last_evolution: self.last_evolution,
                next_evolution: self.last_evolution + Duration::seconds(self.config.evolution_interval_secs as i64),
                mutations_this_cycle: self.mutation_count,
                crossovers_this_cycle: self.crossover_count,
                terminations_this_cycle: self.termination_count,
                new_spawns_this_cycle: self.spawn_count,
                selection_pressure: self.genetic_config.selection_pressure,
                environmental_stress,
                population_health: self.calculate_population_health(&stats, genetic_diversity).await,
            }
        }
    }
    
    /// Collect fitness scores from all organisms
    async fn collect_fitness_scores(
        &self,
        organisms: &Arc<DashMap<Uuid, Box<dyn ParasiticOrganism + Send + Sync>>>,
    ) -> Vec<(Uuid, f64)> {
        organisms
            .iter()
            .map(|entry| (*entry.key(), entry.value().fitness()))
            .collect()
    }
    
    /// Calculate population statistics
    async fn calculate_population_stats(&self, fitness_scores: &[(Uuid, f64)]) -> PopulationStats {
        if fitness_scores.is_empty() {
            return PopulationStats::default();
        }
        
        let fitnesses: Vec<f64> = fitness_scores.iter().map(|(_, f)| *f).collect();
        let total = fitnesses.iter().sum::<f64>();
        let count = fitnesses.len() as f64;
        let average = total / count;
        
        let best = fitnesses.iter().fold(f64::NEG_INFINITY, |a, &b| a.max(b));
        let worst = fitnesses.iter().fold(f64::INFINITY, |a, &b| a.min(b));
        
        let variance = fitnesses.iter()
            .map(|f| (f - average).powi(2))
            .sum::<f64>() / count;
        
        PopulationStats {
            size: fitness_scores.len(),
            average_fitness: average,
            best_fitness: best,
            worst_fitness: worst,
            fitness_variance: variance,
        }
    }
    
    /// Calculate environmental stress factors
    async fn calculate_environmental_stress(&self, stats: &PopulationStats) -> f64 {
        let mut stress = 0.0;
        
        // Low average fitness increases stress
        if stats.average_fitness < 0.3 {
            stress += 0.3;
        }
        
        // Low diversity increases stress
        if stats.fitness_variance < 0.01 {
            stress += 0.2;
        }
        
        // Population size stress
        if stats.size < 10 {
            stress += 0.4;
        } else if stats.size > 200 {
            stress += 0.2;
        }
        
        stress.min(1.0)
    }
    
    /// Determine if evolution should be triggered
    async fn should_trigger_evolution(&self, stats: &PopulationStats, stress: f64) -> bool {
        // Always evolve under high stress
        if stress > 0.7 {
            return true;
        }
        
        // Check if enough time has passed
        let time_since_last = Utc::now() - self.last_evolution;
        let interval = Duration::seconds(self.config.evolution_interval_secs as i64);
        
        time_since_last >= interval || stress > 0.5
    }
    
    /// Selection phase - choose organisms for reproduction
    async fn selection_phase(
        &self,
        organisms: &Arc<DashMap<Uuid, Box<dyn ParasiticOrganism + Send + Sync>>>,
        fitness_scores: &[(Uuid, f64)],
    ) -> Result<Vec<Uuid>, Box<dyn std::error::Error + Send + Sync>> {
        let mut sorted_fitness = fitness_scores.to_vec();
        sorted_fitness.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap());
        
        match &self.selection_strategy {
            SelectionStrategy::Elite { percentage } => {
                let count = (sorted_fitness.len() as f64 * percentage) as usize;
                Ok(sorted_fitness.into_iter().take(count).map(|(id, _)| id).collect())
            }
            SelectionStrategy::Tournament { size } => {
                self.tournament_selection(&sorted_fitness, *size).await
            }
            SelectionStrategy::Roulette => {
                self.roulette_selection(&sorted_fitness).await
            }
            SelectionStrategy::Hybrid { primary, secondary } => {
                // Use primary strategy for top performers, secondary for diversity
                let mut selected = Vec::new();
                
                // Primary selection
                let primary_count = sorted_fitness.len() / 2;
                match primary.as_ref() {
                    SelectionStrategy::Elite { percentage } => {
                        let count = (primary_count as f64 * percentage) as usize;
                        selected.extend(sorted_fitness.iter().take(count).map(|(id, _)| *id));
                    }
                    _ => {}
                }
                
                // Secondary selection from remaining
                match secondary.as_ref() {
                    SelectionStrategy::Tournament { size } => {
                        let remaining: Vec<(Uuid, f64)> = sorted_fitness.into_iter().skip(selected.len()).collect();
                        if !remaining.is_empty() {
                            let additional = self.tournament_selection(&remaining, *size).await?;
                            selected.extend(additional);
                        }
                    }
                    _ => {}
                }
                
                Ok(selected)
            }
        }
    }
    
    /// Tournament selection implementation
    async fn tournament_selection(
        &self,
        fitness_scores: &[(Uuid, f64)],
        tournament_size: usize,
    ) -> Result<Vec<Uuid>, Box<dyn std::error::Error + Send + Sync>> {
        let mut rng = rand::thread_rng();
        let mut selected = Vec::new();
        let selection_count = (fitness_scores.len() as f64 * self.genetic_config.elite_percentage * 2.0) as usize;
        
        for _ in 0..selection_count {
            let tournament: Vec<_> = fitness_scores
                .choose_multiple(&mut rng, tournament_size.min(fitness_scores.len()))
                .collect();
            
            if let Some((id, _)) = tournament.iter().max_by(|a, b| a.1.partial_cmp(&b.1).unwrap()) {
                selected.push(**id);
            }
        }
        
        Ok(selected)
    }
    
    /// Roulette wheel selection implementation
    async fn roulette_selection(
        &self,
        fitness_scores: &[(Uuid, f64)],
    ) -> Result<Vec<Uuid>, Box<dyn std::error::Error + Send + Sync>> {
        let total_fitness: f64 = fitness_scores.iter().map(|(_, f)| f.max(0.0)).sum();
        if total_fitness == 0.0 {
            return Ok(Vec::new());
        }
        
        let mut rng = rand::thread_rng();
        let mut selected = Vec::new();
        let selection_count = (fitness_scores.len() as f64 * self.genetic_config.elite_percentage * 2.0) as usize;
        
        for _ in 0..selection_count {
            let mut spin = rng.gen::<f64>() * total_fitness;
            
            for (id, fitness) in fitness_scores {
                spin -= fitness.max(0.0);
                if spin <= 0.0 {
                    selected.push(*id);
                    break;
                }
            }
        }
        
        Ok(selected)
    }
    
    /// Reproduction phase - crossover and mutation
    async fn reproduction_phase(
        &mut self,
        organisms: &Arc<DashMap<Uuid, Box<dyn ParasiticOrganism + Send + Sync>>>,
        selected: &[Uuid],
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        let mut rng = rand::thread_rng();
        
        // Crossover
        if selected.len() >= 2 && rng.gen::<f64>() < self.genetic_config.crossover_rate {
            for _ in 0..(selected.len() / 2) {
                let parent1_id = selected.choose(&mut rng).unwrap();
                let parent2_id = selected.choose(&mut rng).unwrap();
                
                if parent1_id != parent2_id {
                    if let (Some(parent1), Some(parent2)) = (organisms.get(parent1_id), organisms.get(parent2_id)) {
                        if let Ok(offspring) = parent1.value().crossover(parent2.value().as_ref()) {
                            let offspring_id = offspring.id();
                            organisms.insert(offspring_id, offspring);
                            self.crossover_count += 1;
                            self.spawn_count += 1;
                        }
                    }
                }
            }
        }
        
        // Mutation - Note: This would require interior mutability in practice
        self.mutation_count += (organisms.len() as f64 * self.genetic_config.mutation_rate) as u64;
        
        Ok(())
    }
    
    /// Elimination phase - remove weak organisms
    async fn elimination_phase(
        &mut self,
        organisms: &Arc<DashMap<Uuid, Box<dyn ParasiticOrganism + Send + Sync>>>,
        fitness_scores: &[(Uuid, f64)],
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        // Sort by fitness (ascending for elimination)
        let mut sorted_fitness = fitness_scores.to_vec();
        sorted_fitness.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap());
        
        // Calculate how many to eliminate based on survival threshold
        let eliminate_count = (sorted_fitness.len() as f64 * self.config.survival_threshold) as usize;
        
        // Eliminate weakest organisms
        for (id, fitness) in sorted_fitness.iter().take(eliminate_count) {
            // Also check if organism requests termination
            if let Some(organism) = organisms.get(id) {
                if organism.should_terminate() || *fitness < 0.1 {
                    organisms.remove(id);
                    self.termination_count += 1;
                }
            }
        }
        
        Ok(())
    }
    
    /// Maintain minimum population size
    async fn maintain_population(
        &mut self,
        organisms: &Arc<DashMap<Uuid, Box<dyn ParasiticOrganism + Send + Sync>>>,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        use crate::organisms::{CuckooOrganism, WaspOrganism, VirusOrganism, BacteriaOrganism};
        
        let current_size = organisms.len();
        let target_size = self.genetic_config.population_size;
        
        if current_size < target_size {
            let to_spawn = target_size - current_size;
            
            for _ in 0..to_spawn {
                // Spawn random organism types to maintain diversity
                let organism: Box<dyn ParasiticOrganism + Send + Sync> = match rand::thread_rng().gen_range(0..4) {
                    0 => Box::new(CuckooOrganism::new()),
                    1 => Box::new(WaspOrganism::new()),
                    2 => Box::new(VirusOrganism::new()),
                    _ => Box::new(BacteriaOrganism::new()),
                };
                
                let id = organism.id();
                organisms.insert(id, organism);
                self.spawn_count += 1;
            }
        }
        
        Ok(())
    }
    
    /// Create comprehensive evolution status
    async fn create_evolution_status(
        &self,
        organisms: &Arc<DashMap<Uuid, Box<dyn ParasiticOrganism + Send + Sync>>>,
        environmental_stress: f64,
    ) -> EvolutionStatus {
        let fitness_scores = self.collect_fitness_scores(organisms).await;
        let stats = self.calculate_population_stats(&fitness_scores).await;
        let genetic_diversity = self.calculate_genetic_diversity(organisms).await;
        
        EvolutionStatus {
            current_generation: self.current_generation,
            total_organisms: fitness_scores.len(),
            average_fitness: stats.average_fitness,
            best_fitness: stats.best_fitness,
            worst_fitness: stats.worst_fitness,
            fitness_variance: stats.fitness_variance,
            genetic_diversity,
            last_evolution: self.last_evolution,
            next_evolution: self.last_evolution + Duration::seconds(self.config.evolution_interval_secs as i64),
            mutations_this_cycle: self.mutation_count,
            crossovers_this_cycle: self.crossover_count,
            terminations_this_cycle: self.termination_count,
            new_spawns_this_cycle: self.spawn_count,
            selection_pressure: self.genetic_config.selection_pressure,
            environmental_stress,
            population_health: self.calculate_population_health(&stats, genetic_diversity).await,
        }
    }
    
    /// Calculate genetic diversity across population
    async fn calculate_genetic_diversity(
        &self,
        organisms: &Arc<DashMap<Uuid, Box<dyn ParasiticOrganism + Send + Sync>>>,
    ) -> f64 {
        if organisms.len() < 2 {
            return 0.0;
        }
        
        let mut genetics_vec = Vec::new();
        for entry in organisms.iter() {
            genetics_vec.push(entry.value().get_genetics());
        }
        
        // Calculate genetic diversity using average pairwise distance
        let mut total_distance = 0.0;
        let mut comparisons = 0;
        
        for i in 0..genetics_vec.len() {
            for j in (i + 1)..genetics_vec.len() {
                total_distance += self.genetic_distance(&genetics_vec[i], &genetics_vec[j]);
                comparisons += 1;
            }
        }
        
        if comparisons > 0 {
            total_distance / comparisons as f64
        } else {
            0.0
        }
    }
    
    /// Calculate distance between two genetic profiles
    fn genetic_distance(&self, g1: &OrganismGenetics, g2: &OrganismGenetics) -> f64 {
        let differences = [
            (g1.aggression - g2.aggression).abs(),
            (g1.adaptability - g2.adaptability).abs(),
            (g1.efficiency - g2.efficiency).abs(),
            (g1.resilience - g2.resilience).abs(),
            (g1.reaction_speed - g2.reaction_speed).abs(),
            (g1.risk_tolerance - g2.risk_tolerance).abs(),
            (g1.cooperation - g2.cooperation).abs(),
            (g1.stealth - g2.stealth).abs(),
        ];
        
        // Euclidean distance
        differences.iter().map(|d| d * d).sum::<f64>().sqrt() / 8.0_f64.sqrt()
    }
    
    /// Calculate overall population health
    async fn calculate_population_health(
        &self,
        stats: &PopulationStats,
        genetic_diversity: f64,
    ) -> EvolutionHealth {
        EvolutionHealth {
            stability: (1.0 - stats.fitness_variance.min(1.0)).max(0.0),
            adaptability: genetic_diversity,
            sustainability: (stats.average_fitness * 2.0).min(1.0),
            resilience: ((stats.size as f64) / (self.genetic_config.population_size as f64)).min(1.0),
        }
    }
    
    /// Get evolution history
    pub fn get_evolution_history(&self) -> &[EvolutionStatus] {
        &self.evolution_history
    }
    
    /// Get genetic algorithm configuration
    pub fn get_genetic_config(&self) -> &GeneticAlgorithmConfig {
        &self.genetic_config
    }
    
    /// Update genetic algorithm parameters
    pub fn update_genetic_config(&mut self, config: GeneticAlgorithmConfig) {
        self.genetic_config = config;
    }
}

/// Population statistics helper struct
#[derive(Debug, Clone, Default)]
struct PopulationStats {
    size: usize,
    average_fitness: f64,
    best_fitness: f64,
    worst_fitness: f64,
    fitness_variance: f64,
}