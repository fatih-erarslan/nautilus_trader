//! Analytics engine for parasitic organism performance

use serde::{Serialize, Deserialize};
use uuid::Uuid;
use chrono::{DateTime, Utc, Duration};
use std::collections::{HashMap, VecDeque};
use tokio::sync::RwLock;
use std::sync::Arc;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OrganismAnalytics {
    pub organism_id: Uuid,
    pub organism_type: String,
    pub total_profit: f64,
    pub success_rate: f64,
    pub avg_infection_duration: u64,
    pub resource_efficiency: f64,
    pub adaptations_count: u32,
    pub last_updated: DateTime<Utc>,
    pub performance_metrics: PerformanceMetrics,
    pub efficiency_scores: EfficiencyScores,
    pub behavioral_analysis: BehaviorAnalysis,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PerformanceMetrics {
    pub trades_executed: u64,
    pub avg_latency_ns: u64,
    pub max_latency_ns: u64,
    pub min_latency_ns: u64,
    pub latency_variance: f64,
    pub throughput_per_second: f64,
    pub error_rate: f64,
    pub uptime_percentage: f64,
    pub peak_performance_time: Option<DateTime<Utc>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EfficiencyScores {
    pub resource_utilization: f64,
    pub profit_per_resource_unit: f64,
    pub energy_efficiency: f64,
    pub time_efficiency: f64,
    pub network_efficiency: f64,
    pub memory_efficiency: f64,
    pub overall_efficiency: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BehaviorAnalysis {
    pub aggression_pattern: AggressionPattern,
    pub adaptation_speed: f64,
    pub cooperation_index: f64,
    pub stealth_effectiveness: f64,
    pub market_timing_accuracy: f64,
    pub risk_management_score: f64,
    pub learning_curve: LearningCurve,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AggressionPattern {
    pub intensity: f64,
    pub frequency: f64,
    pub success_rate: f64,
    pub risk_reward_ratio: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LearningCurve {
    pub improvement_rate: f64,
    pub plateau_detection: bool,
    pub adaptability_score: f64,
    pub knowledge_retention: f64,
}

/// Market vulnerability analysis
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VulnerabilityAnalysis {
    pub pair_id: String,
    pub vulnerability_score: f64,
    pub vulnerability_factors: VulnerabilityFactors,
    pub temporal_patterns: TemporalPatterns,
    pub exploitation_potential: ExploitationPotential,
    pub resistance_metrics: ResistanceMetrics,
    pub timestamp: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VulnerabilityFactors {
    pub liquidity_fragmentation: f64,
    pub volatility_clustering: f64,
    pub order_book_imbalance: f64,
    pub whale_activity_level: f64,
    pub algorithmic_predictability: f64,
    pub market_maker_gaps: f64,
    pub correlation_instability: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TemporalPatterns {
    pub peak_vulnerability_hours: Vec<u8>,
    pub cyclical_patterns: HashMap<String, f64>,
    pub seasonal_adjustments: HashMap<String, f64>,
    pub trend_direction: f64,
    pub pattern_reliability: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExploitationPotential {
    pub estimated_profit_range: (f64, f64),
    pub optimal_organism_types: Vec<String>,
    pub required_resources: HashMap<String, f64>,
    pub success_probability: f64,
    pub time_window: Duration,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResistanceMetrics {
    pub adaptive_resistance: f64,
    pub static_resistance: f64,
    pub immune_response_strength: f64,
    pub recovery_speed: f64,
    pub learning_from_attacks: f64,
}

/// Comprehensive analytics engine
pub struct AnalyticsEngine {
    organism_analytics: Arc<RwLock<HashMap<Uuid, OrganismAnalytics>>>,
    vulnerability_cache: Arc<RwLock<HashMap<String, VulnerabilityAnalysis>>>,
    performance_history: Arc<RwLock<HashMap<Uuid, VecDeque<PerformanceSnapshot>>>>,
    market_intelligence: Arc<RwLock<MarketIntelligence>>,
    real_time_metrics: Arc<RwLock<RealTimeMetrics>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PerformanceSnapshot {
    pub timestamp: DateTime<Utc>,
    pub fitness: f64,
    pub profit: f64,
    pub resource_usage: f64,
    pub success_rate: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MarketIntelligence {
    pub global_vulnerability_trend: f64,
    pub dominant_organism_types: HashMap<String, f64>,
    pub emerging_patterns: Vec<String>,
    pub resistance_evolution: HashMap<String, f64>,
    pub optimal_deployment_windows: Vec<TimeWindow>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TimeWindow {
    pub start: DateTime<Utc>,
    pub end: DateTime<Utc>,
    pub confidence: f64,
    pub expected_return: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RealTimeMetrics {
    pub active_infections: u64,
    pub total_organisms: u64,
    pub avg_population_fitness: f64,
    pub system_throughput: f64,
    pub resource_utilization: f64,
    pub alert_level: AlertLevel,
    pub performance_indicators: SystemIndicators,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum AlertLevel {
    Normal,
    Elevated,
    High,
    Critical,
    Emergency,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SystemIndicators {
    pub health_score: f64,
    pub stability_index: f64,
    pub efficiency_rating: f64,
    pub adaptation_speed: f64,
    pub threat_level: f64,
}

impl AnalyticsEngine {
    pub fn new() -> Self {
        Self {
            organism_analytics: Arc::new(RwLock::new(HashMap::new())),
            vulnerability_cache: Arc::new(RwLock::new(HashMap::new())),
            performance_history: Arc::new(RwLock::new(HashMap::new())),
            market_intelligence: Arc::new(RwLock::new(MarketIntelligence {
                global_vulnerability_trend: 0.5,
                dominant_organism_types: HashMap::new(),
                emerging_patterns: Vec::new(),
                resistance_evolution: HashMap::new(),
                optimal_deployment_windows: Vec::new(),
            })),
            real_time_metrics: Arc::new(RwLock::new(RealTimeMetrics {
                active_infections: 0,
                total_organisms: 0,
                avg_population_fitness: 0.0,
                system_throughput: 0.0,
                resource_utilization: 0.0,
                alert_level: AlertLevel::Normal,
                performance_indicators: SystemIndicators {
                    health_score: 1.0,
                    stability_index: 1.0,
                    efficiency_rating: 1.0,
                    adaptation_speed: 0.5,
                    threat_level: 0.0,
                },
            })),
        }
    }
    
    /// Analyze pair vulnerability with comprehensive assessment
    pub async fn analyze_pair_vulnerability(&self, pair_id: &str) -> Result<f64, Box<dyn std::error::Error + Send + Sync>> {
        // Check cache first
        {
            let cache = self.vulnerability_cache.read().await;
            if let Some(cached) = cache.get(pair_id) {
                // Use cached result if less than 5 minutes old
                if Utc::now() - cached.timestamp < Duration::minutes(5) {
                    return Ok(cached.vulnerability_score);
                }
            }
        }
        
        // Perform comprehensive vulnerability analysis
        let analysis = self.perform_vulnerability_analysis(pair_id).await?;
        let vulnerability_score = analysis.vulnerability_score;
        
        // Cache the result
        {
            let mut cache = self.vulnerability_cache.write().await;
            cache.insert(pair_id.to_string(), analysis);
            
            // Cleanup old entries
            let cutoff = Utc::now() - Duration::hours(1);
            cache.retain(|_, v| v.timestamp > cutoff);
        }
        
        Ok(vulnerability_score)
    }
    
    /// Perform detailed vulnerability analysis
    async fn perform_vulnerability_analysis(&self, pair_id: &str) -> Result<VulnerabilityAnalysis, Box<dyn std::error::Error + Send + Sync>> {
        let vulnerability_factors = self.analyze_vulnerability_factors(pair_id).await;
        let temporal_patterns = self.analyze_temporal_patterns(pair_id).await;
        let exploitation_potential = self.assess_exploitation_potential(pair_id, &vulnerability_factors).await;
        let resistance_metrics = self.measure_resistance_metrics(pair_id).await;
        
        // Calculate composite vulnerability score
        let vulnerability_score = self.calculate_composite_vulnerability(&vulnerability_factors);
        
        Ok(VulnerabilityAnalysis {
            pair_id: pair_id.to_string(),
            vulnerability_score,
            vulnerability_factors,
            temporal_patterns,
            exploitation_potential,
            resistance_metrics,
            timestamp: Utc::now(),
        })
    }
    
    /// Analyze vulnerability factors
    async fn analyze_vulnerability_factors(&self, pair_id: &str) -> VulnerabilityFactors {
        // Mock implementation - in practice would analyze real market data
        let base_vulnerability = match pair_id {
            "BTCUSD" | "BTCUSDT" => 0.7,
            "ETHUSD" | "ETHUSDT" => 0.65,
            "ADAUSD" | "ADAUSDT" => 0.8,
            "SOLUSD" | "SOLUSDT" => 0.85,
            _ => 0.5,
        };
        
        // Add random variations to simulate real analysis
        use rand::Rng;
        let mut rng = rand::thread_rng();
        let noise_factor = rng.gen_range(0.8..1.2);
        
        VulnerabilityFactors {
            liquidity_fragmentation: (base_vulnerability * 0.9 * noise_factor).clamp(0.0, 1.0),
            volatility_clustering: (base_vulnerability * 1.1 * noise_factor).clamp(0.0, 1.0),
            order_book_imbalance: (base_vulnerability * 0.8 * noise_factor).clamp(0.0, 1.0),
            whale_activity_level: (base_vulnerability * 1.2 * noise_factor).clamp(0.0, 1.0),
            algorithmic_predictability: (base_vulnerability * 0.7 * noise_factor).clamp(0.0, 1.0),
            market_maker_gaps: (base_vulnerability * 0.9 * noise_factor).clamp(0.0, 1.0),
            correlation_instability: (base_vulnerability * 1.0 * noise_factor).clamp(0.0, 1.0),
        }
    }
    
    /// Analyze temporal vulnerability patterns
    async fn analyze_temporal_patterns(&self, _pair_id: &str) -> TemporalPatterns {
        // Mock implementation
        TemporalPatterns {
            peak_vulnerability_hours: vec![2, 3, 4, 14, 15, 21, 22], // UTC hours
            cyclical_patterns: {
                let mut patterns = HashMap::new();
                patterns.insert("daily".to_string(), 0.8);
                patterns.insert("weekly".to_string(), 0.6);
                patterns.insert("monthly".to_string(), 0.4);
                patterns
            },
            seasonal_adjustments: {
                let mut adjustments = HashMap::new();
                adjustments.insert("market_open".to_string(), 1.2);
                adjustments.insert("market_close".to_string(), 1.1);
                adjustments.insert("weekend".to_string(), 0.7);
                adjustments
            },
            trend_direction: 0.15, // Slightly increasing vulnerability
            pattern_reliability: 0.75,
        }
    }
    
    /// Assess exploitation potential
    async fn assess_exploitation_potential(&self, _pair_id: &str, factors: &VulnerabilityFactors) -> ExploitationPotential {
        let avg_vulnerability = (factors.liquidity_fragmentation + 
                                factors.volatility_clustering + 
                                factors.order_book_imbalance + 
                                factors.whale_activity_level + 
                                factors.algorithmic_predictability + 
                                factors.market_maker_gaps + 
                                factors.correlation_instability) / 7.0;
        
        let profit_base = avg_vulnerability * 1000.0; // Base profit estimate in USD
        
        ExploitationPotential {
            estimated_profit_range: (profit_base * 0.5, profit_base * 2.0),
            optimal_organism_types: {
                let mut types = Vec::new();
                if factors.whale_activity_level > 0.7 { types.push("cuckoo".to_string()); }
                if factors.algorithmic_predictability > 0.6 { types.push("wasp".to_string()); }
                if factors.correlation_instability > 0.8 { types.push("virus".to_string()); }
                if factors.liquidity_fragmentation > 0.6 { types.push("bacteria".to_string()); }
                if types.is_empty() { types.push("cuckoo".to_string()); } // Default
                types
            },
            required_resources: {
                let mut resources = HashMap::new();
                resources.insert("cpu_cores".to_string(), (avg_vulnerability * 4.0).ceil());
                resources.insert("memory_gb".to_string(), (avg_vulnerability * 2.0).ceil());
                resources.insert("bandwidth_mbps".to_string(), (avg_vulnerability * 10.0).ceil());
                resources
            },
            success_probability: avg_vulnerability * 0.9,
            time_window: Duration::hours((12.0 * (1.0 - avg_vulnerability)) as i64).max(Duration::hours(1)),
        }
    }
    
    /// Measure resistance metrics
    async fn measure_resistance_metrics(&self, _pair_id: &str) -> ResistanceMetrics {
        // Mock implementation
        use rand::Rng;
        let mut rng = rand::thread_rng();
        
        ResistanceMetrics {
            adaptive_resistance: rng.gen_range(0.2..0.8),
            static_resistance: rng.gen_range(0.1..0.6),
            immune_response_strength: rng.gen_range(0.3..0.7),
            recovery_speed: rng.gen_range(0.4..0.9),
            learning_from_attacks: rng.gen_range(0.2..0.6),
        }
    }
    
    /// Calculate composite vulnerability score
    fn calculate_composite_vulnerability(&self, factors: &VulnerabilityFactors) -> f64 {
        // Weighted average of vulnerability factors
        let weights = [0.15, 0.20, 0.12, 0.18, 0.10, 0.15, 0.10]; // Sum = 1.0
        let values = [
            factors.liquidity_fragmentation,
            factors.volatility_clustering,
            factors.order_book_imbalance,
            factors.whale_activity_level,
            factors.algorithmic_predictability,
            factors.market_maker_gaps,
            factors.correlation_instability,
        ];
        
        weights.iter()
            .zip(values.iter())
            .map(|(w, v)| w * v)
            .sum::<f64>()
            .clamp(0.0, 1.0)
    }
    
    /// Get comprehensive organism analytics
    pub async fn get_organism_analytics(&self, organism_id: Uuid) -> Option<OrganismAnalytics> {
        let analytics = self.organism_analytics.read().await;
        analytics.get(&organism_id).cloned()
    }
    
    /// Update organism performance metrics
    pub async fn update_organism_performance(&self, organism_id: Uuid, organism_type: &str, fitness: f64, profit: f64) {
        let mut analytics = self.organism_analytics.write().await;
        
        let entry = analytics.entry(organism_id).or_insert_with(|| OrganismAnalytics {
            organism_id,
            organism_type: organism_type.to_string(),
            total_profit: 0.0,
            success_rate: 0.5,
            avg_infection_duration: 3600,
            resource_efficiency: 0.5,
            adaptations_count: 0,
            last_updated: Utc::now(),
            performance_metrics: PerformanceMetrics {
                trades_executed: 0,
                avg_latency_ns: 50_000,
                max_latency_ns: 100_000,
                min_latency_ns: 10_000,
                latency_variance: 25_000.0,
                throughput_per_second: 10.0,
                error_rate: 0.05,
                uptime_percentage: 99.0,
                peak_performance_time: None,
            },
            efficiency_scores: EfficiencyScores {
                resource_utilization: 0.7,
                profit_per_resource_unit: 10.0,
                energy_efficiency: 0.8,
                time_efficiency: 0.6,
                network_efficiency: 0.75,
                memory_efficiency: 0.85,
                overall_efficiency: 0.7,
            },
            behavioral_analysis: BehaviorAnalysis {
                aggression_pattern: AggressionPattern {
                    intensity: 0.5,
                    frequency: 0.5,
                    success_rate: 0.6,
                    risk_reward_ratio: 1.2,
                },
                adaptation_speed: 0.6,
                cooperation_index: 0.4,
                stealth_effectiveness: 0.7,
                market_timing_accuracy: 0.65,
                risk_management_score: 0.8,
                learning_curve: LearningCurve {
                    improvement_rate: 0.1,
                    plateau_detection: false,
                    adaptability_score: 0.7,
                    knowledge_retention: 0.85,
                },
            },
        });
        
        // Update metrics
        entry.total_profit += profit;
        entry.last_updated = Utc::now();
        
        // Update performance snapshot
        let snapshot = PerformanceSnapshot {
            timestamp: Utc::now(),
            fitness,
            profit,
            resource_usage: 0.6, // Mock value
            success_rate: entry.success_rate,
        };
        
        // Store performance history
        {
            let mut history = self.performance_history.write().await;
            let organism_history = history.entry(organism_id).or_insert_with(VecDeque::new);
            organism_history.push_back(snapshot);
            
            // Keep only last 1000 snapshots
            if organism_history.len() > 1000 {
                organism_history.pop_front();
            }
        }
    }
    
    /// Get performance history for an organism
    pub async fn get_performance_history(&self, organism_id: Uuid, limit: Option<usize>) -> Vec<PerformanceSnapshot> {
        let history = self.performance_history.read().await;
        if let Some(organism_history) = history.get(&organism_id) {
            let limit = limit.unwrap_or(100);
            organism_history.iter()
                .rev()
                .take(limit)
                .cloned()
                .collect::<Vec<_>>()
                .into_iter()
                .rev()
                .collect()
        } else {
            Vec::new()
        }
    }
    
    /// Get real-time system metrics
    pub async fn get_real_time_metrics(&self) -> RealTimeMetrics {
        self.real_time_metrics.read().await.clone()
    }
    
    /// Update real-time metrics
    pub async fn update_real_time_metrics(&self, active_infections: u64, total_organisms: u64, avg_fitness: f64) {
        let mut metrics = self.real_time_metrics.write().await;
        metrics.active_infections = active_infections;
        metrics.total_organisms = total_organisms;
        metrics.avg_population_fitness = avg_fitness;
        
        // Calculate derived metrics
        metrics.system_throughput = active_infections as f64 * 10.0; // Mock calculation
        metrics.resource_utilization = (active_infections as f64 / 100.0).clamp(0.0, 1.0);
        
        // Update alert level based on system state
        metrics.alert_level = if avg_fitness < 0.2 {
            AlertLevel::Critical
        } else if avg_fitness < 0.4 {
            AlertLevel::High
        } else if avg_fitness < 0.6 {
            AlertLevel::Elevated
        } else {
            AlertLevel::Normal
        };
        
        // Update system indicators
        metrics.performance_indicators.health_score = avg_fitness;
        metrics.performance_indicators.stability_index = (1.0 - (active_infections as f64 / 200.0)).clamp(0.0, 1.0);
        metrics.performance_indicators.efficiency_rating = metrics.resource_utilization;
        metrics.performance_indicators.adaptation_speed = avg_fitness * 0.8;
        metrics.performance_indicators.threat_level = match metrics.alert_level {
            AlertLevel::Normal => 0.1,
            AlertLevel::Elevated => 0.3,
            AlertLevel::High => 0.6,
            AlertLevel::Critical => 0.8,
            AlertLevel::Emergency => 1.0,
        };
    }
    
    /// Get market intelligence summary
    pub async fn get_market_intelligence(&self) -> MarketIntelligence {
        self.market_intelligence.read().await.clone()
    }
    
    /// Generate comprehensive analytics report
    pub async fn generate_analytics_report(&self) -> AnalyticsReport {
        let analytics = self.organism_analytics.read().await;
        let real_time = self.get_real_time_metrics().await;
        let market_intel = self.get_market_intelligence().await;
        
        AnalyticsReport {
            timestamp: Utc::now(),
            summary: ReportSummary {
                total_organisms: analytics.len(),
                active_infections: real_time.active_infections,
                total_profit: analytics.values().map(|a| a.total_profit).sum(),
                avg_success_rate: if !analytics.is_empty() {
                    analytics.values().map(|a| a.success_rate).sum::<f64>() / analytics.len() as f64
                } else {
                    0.0
                },
                system_health: real_time.performance_indicators.health_score,
            },
            organism_rankings: self.generate_organism_rankings(&analytics).await,
            performance_trends: self.analyze_performance_trends().await,
            market_insights: market_intel,
            recommendations: self.generate_recommendations(&analytics, &real_time).await,
        }
    }
    
    /// Generate organism rankings
    async fn generate_organism_rankings(&self, analytics: &HashMap<Uuid, OrganismAnalytics>) -> Vec<OrganismRanking> {
        let mut rankings: Vec<_> = analytics.values()
            .map(|a| OrganismRanking {
                organism_id: a.organism_id,
                organism_type: a.organism_type.clone(),
                rank: 0, // Will be set after sorting
                score: a.total_profit * a.success_rate * a.resource_efficiency,
                total_profit: a.total_profit,
                success_rate: a.success_rate,
                efficiency: a.resource_efficiency,
            })
            .collect();
        
        rankings.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap());
        
        for (i, ranking) in rankings.iter_mut().enumerate() {
            ranking.rank = i + 1;
        }
        
        rankings
    }
    
    /// Analyze performance trends
    async fn analyze_performance_trends(&self) -> PerformanceTrends {
        // Mock implementation
        PerformanceTrends {
            fitness_trend: 0.05, // 5% improvement
            profit_trend: 0.12, // 12% increase
            efficiency_trend: -0.02, // 2% decrease
            success_rate_trend: 0.08, // 8% improvement
            prediction_confidence: 0.75,
        }
    }
    
    /// Generate recommendations
    async fn generate_recommendations(&self, analytics: &HashMap<Uuid, OrganismAnalytics>, real_time: &RealTimeMetrics) -> Vec<Recommendation> {
        let mut recommendations = Vec::new();
        
        // System health recommendations
        if real_time.performance_indicators.health_score < 0.6 {
            recommendations.push(Recommendation {
                priority: RecommendationPriority::High,
                category: "System Health".to_string(),
                title: "Population Health Critical".to_string(),
                description: "Average population fitness is below optimal threshold".to_string(),
                action: "Consider triggering evolution cycle or spawning new organisms".to_string(),
                expected_impact: 0.3,
            });
        }
        
        // Resource utilization recommendations
        if real_time.resource_utilization > 0.8 {
            recommendations.push(Recommendation {
                priority: RecommendationPriority::Medium,
                category: "Resource Management".to_string(),
                title: "High Resource Utilization".to_string(),
                description: "System resource utilization is approaching limits".to_string(),
                action: "Scale down low-performing organisms or optimize resource allocation".to_string(),
                expected_impact: 0.2,
            });
        }
        
        // Diversity recommendations
        let organism_types: std::collections::HashSet<_> = analytics.values()
            .map(|a| &a.organism_type)
            .collect();
        
        if organism_types.len() < 3 {
            recommendations.push(Recommendation {
                priority: RecommendationPriority::Medium,
                category: "Genetic Diversity".to_string(),
                title: "Low Population Diversity".to_string(),
                description: "Population lacks genetic diversity for optimal adaptation".to_string(),
                action: "Spawn organisms of underrepresented types".to_string(),
                expected_impact: 0.25,
            });
        }
        
        recommendations
    }
}

/// Analytics report structures
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalyticsReport {
    pub timestamp: DateTime<Utc>,
    pub summary: ReportSummary,
    pub organism_rankings: Vec<OrganismRanking>,
    pub performance_trends: PerformanceTrends,
    pub market_insights: MarketIntelligence,
    pub recommendations: Vec<Recommendation>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReportSummary {
    pub total_organisms: usize,
    pub active_infections: u64,
    pub total_profit: f64,
    pub avg_success_rate: f64,
    pub system_health: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OrganismRanking {
    pub organism_id: Uuid,
    pub organism_type: String,
    pub rank: usize,
    pub score: f64,
    pub total_profit: f64,
    pub success_rate: f64,
    pub efficiency: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PerformanceTrends {
    pub fitness_trend: f64,
    pub profit_trend: f64,
    pub efficiency_trend: f64,
    pub success_rate_trend: f64,
    pub prediction_confidence: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Recommendation {
    pub priority: RecommendationPriority,
    pub category: String,
    pub title: String,
    pub description: String,
    pub action: String,
    pub expected_impact: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum RecommendationPriority {
    Low,
    Medium,
    High,
    Critical,
}