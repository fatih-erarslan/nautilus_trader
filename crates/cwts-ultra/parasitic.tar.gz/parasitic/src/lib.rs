//! # CWTS Parasitic Trading Engine
//! 
//! A bio-inspired parasitic trading strategy engine that adapts and evolves
//! trading behaviors based on market conditions and pair vulnerabilities.
//!
//! ## Architecture
//! 
//! - **Organisms**: Different parasitic strategies (Cuckoo, Wasp, Virus, etc.)
//! - **Evolution**: Genetic algorithm for strategy adaptation
//! - **MCP Server**: Ultra-low latency Model Context Protocol interface
//! - **Real-time Streaming**: WebSocket-based event broadcasting

pub mod organisms;
pub mod evolution;
pub mod mcp_server;
pub mod analytics;
pub mod pair_analyzer;
pub mod quantum;
pub mod websocket_reconnection;

#[cfg(test)]
pub mod tests;

pub use organisms::*;
pub use evolution::*;
pub use mcp_server::*;
pub use analytics::*;
pub use pair_analyzer::*;

use std::sync::Arc;
use tokio::sync::RwLock;
use dashmap::DashMap;
use serde::{Serialize, Deserialize};
use chrono::{DateTime, Utc};
use uuid::Uuid;

/// Global parasitic engine state
pub type ParasiticEngine = Arc<ParasiticEngineInner>;

/// Core parasitic trading engine
pub struct ParasiticEngineInner {
    /// Active parasitic organisms
    pub organisms: Arc<DashMap<Uuid, Box<dyn ParasiticOrganism + Send + Sync>>>,
    
    /// Infected trading pairs
    pub infected_pairs: Arc<RwLock<Vec<InfectedPair>>>,
    
    /// Evolution engine
    pub evolution_engine: Arc<EvolutionEngine>,
    
    /// MCP server for external communication
    pub mcp_server: Arc<RwLock<Option<ParasiticMCPServer>>>,
    
    /// Analytics engine
    pub analytics: Arc<AnalyticsEngine>,
    
    /// Configuration
    pub config: ParasiticConfig,
}

/// Configuration for the parasitic engine
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ParasiticConfig {
    /// Maximum number of simultaneous infections
    pub max_infections: usize,
    
    /// Evolution cycle interval (seconds)
    pub evolution_interval_secs: u64,
    
    /// Minimum fitness threshold for survival
    pub survival_threshold: f64,
    
    /// Mutation rate for genetic algorithm
    pub mutation_rate: f64,
    
    /// MCP server configuration
    pub mcp_config: MCPServerConfig,
    
    /// Performance optimization settings
    pub performance: PerformanceConfig,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MCPServerConfig {
    pub bind_address: String,
    pub port: u16,
    pub max_connections: usize,
    pub buffer_size: usize,
    pub heartbeat_interval_ms: u64,
    pub quantum_enabled: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PerformanceConfig {
    /// Use SIMD optimizations
    pub enable_simd: bool,
    
    /// Enable lock-free data structures
    pub enable_lockfree: bool,
    
    /// Buffer sizes for low-latency communication
    pub websocket_buffer_size: usize,
    pub broadcast_buffer_size: usize,
    
    /// Processing thread pool size
    pub thread_pool_size: usize,
}

impl Default for ParasiticConfig {
    fn default() -> Self {
        Self {
            max_infections: 100,
            evolution_interval_secs: 300, // 5 minutes
            survival_threshold: 0.3,
            mutation_rate: 0.1,
            mcp_config: MCPServerConfig {
                bind_address: "127.0.0.1".to_string(),
                port: 3001,
                max_connections: 1000,
                buffer_size: 8192,
                heartbeat_interval_ms: 30000,
                quantum_enabled: false,
            },
            performance: PerformanceConfig {
                enable_simd: true,
                enable_lockfree: true,
                websocket_buffer_size: 16384,
                broadcast_buffer_size: 32768,
                thread_pool_size: num_cpus::get().max(4),
            },
        }
    }
}

/// Represents a trading pair that has been infected by a parasitic organism
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InfectedPair {
    pub pair_id: String,
    pub organism_id: Uuid,
    pub infection_time: DateTime<Utc>,
    pub infection_strength: f64,
    pub vulnerability_score: f64,
    pub performance_metrics: InfectionMetrics,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InfectionMetrics {
    pub profit_extracted: f64,
    pub trades_executed: u64,
    pub success_rate: f64,
    pub avg_latency_ns: u64,
    pub adaptation_cycles: u32,
}

impl ParasiticEngineInner {
    /// Create a new parasitic engine
    pub fn new(config: ParasiticConfig) -> ParasiticEngine {
        Arc::new(Self {
            organisms: Arc::new(DashMap::new()),
            infected_pairs: Arc::new(RwLock::new(Vec::new())),
            evolution_engine: Arc::new(EvolutionEngine::new(&config)),
            mcp_server: Arc::new(RwLock::new(None)),
            analytics: Arc::new(AnalyticsEngine::new()),
            config,
        })
    }
    
    /// Initialize the engine and start background tasks
    pub async fn initialize(&self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        // Initialize default organisms
        self.spawn_initial_organisms().await?;
        
        // Start evolution engine
        self.start_evolution_cycle().await?;
        
        // Initialize MCP server
        let mcp_server = ParasiticMCPServer::new(&self.config.mcp_config).await?;
        *self.mcp_server.write().await = Some(mcp_server);
        
        Ok(())
    }
    
    /// Start the MCP server
    pub async fn start_mcp_server(&self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        if let Some(ref server) = *self.mcp_server.read().await {
            server.start().await?;
        }
        Ok(())
    }
    
    /// Spawn initial parasitic organisms
    async fn spawn_initial_organisms(&self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        use crate::organisms::cordyceps::{CordycepsOrganism, CordycepsConfig, SIMDLevel, StealthConfig};
        use crate::quantum::QuantumMode;
        
        // Check global quantum mode for Cordyceps configuration
        let quantum_mode = QuantumMode::current();
        let quantum_enabled = quantum_mode.is_quantum_enabled();
        
        // Create Cordyceps configuration based on quantum mode
        let cordyceps_config = CordycepsConfig {
            max_infections: 15,
            spore_production_rate: 3.0,
            neural_control_strength: if quantum_enabled { 2.5 } else { 2.0 },
            quantum_enabled, // Automatically enabled if quantum mode is active
            simd_level: match quantum_mode {
                QuantumMode::Full => SIMDLevel::Quantum,
                QuantumMode::Enhanced => SIMDLevel::Advanced,
                QuantumMode::Classical => SIMDLevel::Basic,
            },
            infection_radius: if quantum_enabled { 10.0 } else { 8.0 },
            min_host_fitness: 0.2,
            stealth_mode: StealthConfig {
                pattern_camouflage: true,
                behavior_mimicry: true,
                temporal_jittering: true,
                operation_fragmentation: quantum_enabled, // Enable for quantum modes
            },
        };
        
        // Create different types of organisms
        let organisms = vec![
            Box::new(CuckooOrganism::new()) as Box<dyn ParasiticOrganism + Send + Sync>,
            Box::new(WaspOrganism::new()) as Box<dyn ParasiticOrganism + Send + Sync>,
            Box::new(VirusOrganism::new()) as Box<dyn ParasiticOrganism + Send + Sync>,
            Box::new(BacteriaOrganism::new()) as Box<dyn ParasiticOrganism + Send + Sync>,
            Box::new(CordycepsOrganism::new(cordyceps_config)?) as Box<dyn ParasiticOrganism + Send + Sync>,
        ];
        
        for organism in organisms {
            let id = organism.id();
            self.organisms.insert(id, organism);
        }
        
        Ok(())
    }
    
    /// Start the evolution cycle
    async fn start_evolution_cycle(&self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        let evolution_engine = self.evolution_engine.clone();
        let organisms = self.organisms.clone();
        let interval = self.config.evolution_interval_secs;
        
        tokio::spawn(async move {
            let mut interval_timer = tokio::time::interval(
                tokio::time::Duration::from_secs(interval)
            );
            
            loop {
                interval_timer.tick().await;
                
                // Run evolution cycle
                if let Err(e) = evolution_engine.evolve_organisms(&organisms).await {
                    tracing::error!("Evolution cycle failed: {}", e);
                }
            }
        });
        
        Ok(())
    }
    
    /// Infect a trading pair with a specific organism
    pub async fn infect_pair(
        &self,
        pair_id: String,
        organism_id: Uuid,
    ) -> Result<InfectedPair, Box<dyn std::error::Error + Send + Sync>> {
        // Check if organism exists
        let organism = self.organisms.get(&organism_id)
            .ok_or("Organism not found")?;
            
        // Analyze pair vulnerability
        let vulnerability_score = self.analytics.analyze_pair_vulnerability(&pair_id).await?;
        
        // Create infection
        let infection = InfectedPair {
            pair_id: pair_id.clone(),
            organism_id,
            infection_time: Utc::now(),
            infection_strength: organism.calculate_infection_strength(vulnerability_score),
            vulnerability_score,
            performance_metrics: InfectionMetrics {
                profit_extracted: 0.0,
                trades_executed: 0,
                success_rate: 0.0,
                avg_latency_ns: 0,
                adaptation_cycles: 0,
            },
        };
        
        // Add to infected pairs
        let mut infected_pairs = self.infected_pairs.write().await;
        infected_pairs.push(infection.clone());
        
        // Start infection process
        let organism_clone = organism.value().clone();
        tokio::spawn(async move {
            let _ = organism_clone.infect_pair(&pair_id, vulnerability_score).await;
        });
        
        Ok(infection)
    }
    
    /// Get all currently infected pairs
    pub async fn get_infected_pairs(&self) -> Vec<InfectedPair> {
        self.infected_pairs.read().await.clone()
    }
    
    /// Get evolution status
    pub async fn get_evolution_status(&self) -> EvolutionStatus {
        self.evolution_engine.get_status(&self.organisms).await
    }
    
    /// Get analytics for a specific organism
    pub async fn get_organism_analytics(&self, organism_id: Uuid) -> Option<OrganismAnalytics> {
        self.analytics.get_organism_analytics(organism_id).await
    }
}

/// Example usage and integration patterns
impl ParasiticEngineInner {
    /// Complete setup and start the parasitic trading system
    pub async fn start_complete_system(
        config: Option<ParasiticConfig>,
    ) -> Result<ParasiticEngine, Box<dyn std::error::Error + Send + Sync>> {
        let config = config.unwrap_or_default();
        let engine = Self::new(config);
        
        // Initialize all components
        engine.initialize().await?;
        
        println!("🧬 Parasitic Trading Engine initialized");
        println!("   - {} organisms spawned", engine.organisms.len());
        println!("   - MCP server configured on {}:{}", 
                engine.config.mcp_config.bind_address,
                engine.config.mcp_config.port);
        
        // Start MCP server in background
        let engine_clone = engine.clone();
        tokio::spawn(async move {
            if let Err(e) = engine_clone.start_mcp_server().await {
                tracing::error!("MCP server failed: {}", e);
            }
        });
        
        Ok(engine)
    }
    
    /// Quick infection example
    pub async fn quick_infect_example(&self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        // Get a cuckoo organism
        let cuckoo_id = self.organisms
            .iter()
            .find(|entry| entry.value().organism_type() == "cuckoo")
            .map(|entry| *entry.key())
            .ok_or("No cuckoo organism found")?;
        
        // Infect BTCUSD pair
        let infection = self.infect_pair("BTCUSD".to_string(), cuckoo_id).await?;
        
        println!("🦠 Successfully infected {} with cuckoo organism", infection.pair_id);
        println!("   - Infection strength: {:.2}", infection.infection_strength);
        println!("   - Vulnerability score: {:.2}", infection.vulnerability_score);
        
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[tokio::test]
    async fn test_engine_initialization() {
        let config = ParasiticConfig::default();
        let engine = ParasiticEngineInner::new(config);
        
        assert!(engine.initialize().await.is_ok());
        assert!(!engine.organisms.is_empty());
    }
    
    #[tokio::test]
    async fn test_complete_system_startup() {
        let engine = ParasiticEngineInner::start_complete_system(None).await;
        assert!(engine.is_ok());
        
        let engine = engine.unwrap();
        assert_eq!(engine.organisms.len(), 4); // 4 organism types
    }
    
    #[tokio::test] 
    async fn test_quick_infection() {
        let engine = ParasiticEngineInner::start_complete_system(None).await.unwrap();
        
        let result = engine.quick_infect_example().await;
        assert!(result.is_ok());
        
        let infected_pairs = engine.get_infected_pairs().await;
        assert_eq!(infected_pairs.len(), 1);
        assert_eq!(infected_pairs[0].pair_id, "BTCUSD");
    }
}