//! # MCP Server Integration Tests
//! 
//! Comprehensive integration tests for the parasitic MCP server to ensure
//! 100% compliance with MCP spec v2024-11-05 and <50μs response time requirements.

use std::time::{Duration, Instant};
use tokio::net::TcpStream;
use tokio_tungstenite::{connect_async, MaybeTlsStream, WebSocketStream};
use tungstenite::Message;
use serde_json::{json, Value};
use uuid::Uuid;
use parasitic::mcp_server::{ParasiticMCPServer, MCPServerConfig, MCPMessage};
use futures_util::{SinkExt, StreamExt};

type WsStream = WebSocketStream<MaybeTlsStream<TcpStream>>;

/// Test fixture for MCP server integration tests
struct MCPServerTestFixture {
    server_url: String,
    websocket: Option<WsStream>,
    request_id: u64,
}

impl MCPServerTestFixture {
    async fn new() -> Self {
        let config = MCPServerConfig {
            bind_address: "127.0.0.1".to_string(),
            port: 0, // Use any available port
            max_connections: 10,
            buffer_size: 1024,
            heartbeat_interval_ms: 5000,
        };
        
        // Start server in background
        let server = ParasiticMCPServer::new(&config).await.unwrap();
        let port = server.get_port();
        let server_url = format!("ws://127.0.0.1:{}/mcp", port);
        
        // Start server task
        tokio::spawn(async move {
            server.start().await.unwrap();
        });
        
        // Wait for server to start
        tokio::time::sleep(Duration::from_millis(100)).await;
        
        Self {
            server_url,
            websocket: None,
            request_id: 1,
        }
    }
    
    async fn connect(&mut self) -> Result<(), Box<dyn std::error::Error>> {
        let (ws_stream, _) = connect_async(&self.server_url).await?;
        self.websocket = Some(ws_stream);
        Ok(())
    }
    
    async fn send_request(&mut self, method: &str, params: Value) -> Result<MCPMessage, Box<dyn std::error::Error>> {
        let ws = self.websocket.as_mut().ok_or("Not connected")?;
        
        let request = MCPMessage {
            jsonrpc: "2.0".to_string(),
            id: Some(json!(self.request_id)),
            method: Some(method.to_string()),
            params: Some(params),
            result: None,
            error: None,
            _timestamp: None,
        };
        
        self.request_id += 1;
        
        let request_text = serde_json::to_string(&request)?;
        let start_time = Instant::now();
        
        // Send request
        ws.send(Message::Text(request_text)).await?;
        
        // Wait for response
        if let Some(response_msg) = ws.next().await {
            let response_time = start_time.elapsed();
            
            // Verify response time requirement
            assert!(response_time < Duration::from_micros(50), 
                   "Response time {}μs exceeds 50μs requirement", 
                   response_time.as_micros());
            
            let response_text = response_msg?.into_text()?;
            let response: MCPMessage = serde_json::from_str(&response_text)?;
            
            return Ok(response);
        }
        
        Err("No response received".into())
    }
}

#[tokio::test]
async fn test_mcp_initialization_flow() {
    let mut fixture = MCPServerTestFixture::new().await;
    fixture.connect().await.unwrap();
    
    // Test initialization
    let response = fixture.send_request("initialize", json!({
        "protocolVersion": "2024-11-05",
        "capabilities": {
            "roots": {
                "listChanged": false
            },
            "sampling": {}
        },
        "clientInfo": {
            "name": "test-client",
            "version": "1.0.0"
        }
    })).await.unwrap();
    
    assert!(response.error.is_none(), "Initialize should not error: {:?}", response.error);
    assert!(response.result.is_some(), "Initialize should return result");
    
    let result = response.result.unwrap();
    assert_eq!(result["protocolVersion"], "2024-11-05");
    assert!(result["capabilities"]["parasitic"].as_bool().unwrap_or(false));
    assert!(result["capabilities"]["simd"].as_bool().unwrap_or(false));
    
    // Send initialized notification
    let response = fixture.send_request("initialized", json!({})).await.unwrap();
    assert!(response.error.is_none(), "Initialized should not error");
}

#[tokio::test]
async fn test_resources_list_and_read() {
    let mut fixture = MCPServerTestFixture::new().await;
    fixture.connect().await.unwrap();
    
    // Initialize first
    fixture.send_request("initialize", json!({
        "protocolVersion": "2024-11-05",
        "capabilities": {}
    })).await.unwrap();
    
    // Test resources list
    let response = fixture.send_request("resources/list", json!({})).await.unwrap();
    assert!(response.error.is_none(), "Resources list should not error");
    
    let resources = response.result.unwrap()["resources"].as_array().unwrap();
    assert!(!resources.is_empty(), "Should have resources available");
    
    // Test reading first resource
    let first_resource_uri = resources[0]["uri"].as_str().unwrap();
    let response = fixture.send_request("resources/read", json!({
        "uri": first_resource_uri
    })).await.unwrap();
    
    assert!(response.error.is_none(), "Resource read should not error");
    assert!(response.result.is_some(), "Resource read should return content");
}

#[tokio::test]
async fn test_tools_list_and_call() {
    let mut fixture = MCPServerTestFixture::new().await;
    fixture.connect().await.unwrap();
    
    // Initialize first
    fixture.send_request("initialize", json!({
        "protocolVersion": "2024-11-05",
        "capabilities": {}
    })).await.unwrap();
    
    // Test tools list
    let response = fixture.send_request("tools/list", json!({})).await.unwrap();
    assert!(response.error.is_none(), "Tools list should not error");
    
    let tools = response.result.unwrap()["tools"].as_array().unwrap();
    assert!(!tools.is_empty(), "Should have tools available");
    
    // Find parasitic_spawn tool
    let spawn_tool = tools.iter().find(|tool| 
        tool["name"].as_str() == Some("parasitic_spawn")
    ).expect("Should have parasitic_spawn tool");
    
    // Test calling parasitic_spawn tool
    let response = fixture.send_request("tools/call", json!({
        "name": "parasitic_spawn",
        "arguments": {
            "organism_type": "cuckoo",
            "config": {
                "max_eggs": 5,
                "stealth_level": 0.7
            }
        }
    })).await.unwrap();
    
    assert!(response.error.is_none(), "Tool call should not error");
    assert!(response.result.is_some(), "Tool call should return result");
}

#[tokio::test]
async fn test_prompts_list_and_get() {
    let mut fixture = MCPServerTestFixture::new().await;
    fixture.connect().await.unwrap();
    
    // Initialize first
    fixture.send_request("initialize", json!({
        "protocolVersion": "2024-11-05",
        "capabilities": {}
    })).await.unwrap();
    
    // Test prompts list
    let response = fixture.send_request("prompts/list", json!({})).await.unwrap();
    assert!(response.error.is_none(), "Prompts list should not error");
    
    let prompts = response.result.unwrap()["prompts"].as_array().unwrap();
    assert!(!prompts.is_empty(), "Should have prompts available");
    
    // Test getting first prompt
    let first_prompt_name = prompts[0]["name"].as_str().unwrap();
    let response = fixture.send_request("prompts/get", json!({
        "name": first_prompt_name,
        "arguments": {
            "market_pair": "BTC/USDT"
        }
    })).await.unwrap();
    
    assert!(response.error.is_none(), "Prompt get should not error");
    assert!(response.result.is_some(), "Prompt get should return content");
}

#[tokio::test]
async fn test_completion_functionality() {
    let mut fixture = MCPServerTestFixture::new().await;
    fixture.connect().await.unwrap();
    
    // Initialize first
    fixture.send_request("initialize", json!({
        "protocolVersion": "2024-11-05",
        "capabilities": {}
    })).await.unwrap();
    
    // Test completion
    let response = fixture.send_request("completion/complete", json!({
        "ref": {
            "uri": "prompt://parasitic_strategy"
        },
        "argument": {
            "name": "market_pair",
            "value": "BTC"
        }
    })).await.unwrap();
    
    assert!(response.error.is_none(), "Completion should not error");
    
    let completion = &response.result.unwrap()["completion"];
    let values = completion["values"].as_array().unwrap();
    assert!(!values.is_empty(), "Should have completion values");
}

#[tokio::test]
async fn test_logging_and_ping() {
    let mut fixture = MCPServerTestFixture::new().await;
    fixture.connect().await.unwrap();
    
    // Initialize first
    fixture.send_request("initialize", json!({
        "protocolVersion": "2024-11-05",
        "capabilities": {}
    })).await.unwrap();
    
    // Test set log level
    let response = fixture.send_request("logging/setLevel", json!({
        "level": "debug"
    })).await.unwrap();
    
    assert!(response.error.is_none(), "Set log level should not error");
    assert!(response.result.unwrap()["success"].as_bool().unwrap());
    
    // Test ping
    let response = fixture.send_request("ping", json!({})).await.unwrap();
    assert!(response.error.is_none(), "Ping should not error");
    assert!(response.result.unwrap()["pong"].as_bool().unwrap());
}

#[tokio::test]
async fn test_resource_subscription() {
    let mut fixture = MCPServerTestFixture::new().await;
    fixture.connect().await.unwrap();
    
    // Initialize first
    fixture.send_request("initialize", json!({
        "protocolVersion": "2024-11-05",
        "capabilities": {}
    })).await.unwrap();
    
    // Test subscribe to resource
    let response = fixture.send_request("resources/subscribe", json!({
        "uri": "parasitic://organisms/status"
    })).await.unwrap();
    
    assert!(response.error.is_none(), "Resource subscribe should not error");
    assert!(response.result.unwrap()["subscribed"].as_bool().unwrap());
    
    // Test unsubscribe
    let response = fixture.send_request("resources/unsubscribe", json!({
        "uri": "parasitic://organisms/status"
    })).await.unwrap();
    
    assert!(response.error.is_none(), "Resource unsubscribe should not error");
    assert!(response.result.unwrap()["unsubscribed"].as_bool().unwrap());
}

#[tokio::test]
async fn test_error_handling_and_validation() {
    let mut fixture = MCPServerTestFixture::new().await;
    fixture.connect().await.unwrap();
    
    // Test invalid method
    let response = fixture.send_request("invalid_method", json!({})).await.unwrap();
    assert!(response.error.is_some(), "Invalid method should return error");
    assert_eq!(response.error.unwrap().code, -32601); // Method not found
    
    // Test invalid parameters
    let response = fixture.send_request("resources/read", json!({
        "invalid_param": "value"
    })).await.unwrap();
    assert!(response.error.is_some(), "Invalid parameters should return error");
    
    // Test invalid log level
    let response = fixture.send_request("logging/setLevel", json!({
        "level": "invalid_level"
    })).await.unwrap();
    assert!(response.error.is_some(), "Invalid log level should return error");
    assert_eq!(response.error.unwrap().code, -32602); // Invalid params
}

#[tokio::test]
async fn test_performance_requirements() {
    let mut fixture = MCPServerTestFixture::new().await;
    fixture.connect().await.unwrap();
    
    // Initialize first
    fixture.send_request("initialize", json!({
        "protocolVersion": "2024-11-05",
        "capabilities": {}
    })).await.unwrap();
    
    // Test multiple rapid requests to ensure performance
    let iterations = 100;
    let mut total_time = Duration::new(0, 0);
    
    for _ in 0..iterations {
        let start = Instant::now();
        let response = fixture.send_request("ping", json!({})).await.unwrap();
        let elapsed = start.elapsed();
        
        assert!(response.error.is_none(), "Ping should not error");
        assert!(elapsed < Duration::from_micros(50), 
               "Each request should be <50μs, got {}μs", elapsed.as_micros());
        
        total_time += elapsed;
    }
    
    let avg_time = total_time / iterations;
    println!("Average response time: {}μs", avg_time.as_micros());
    assert!(avg_time < Duration::from_micros(50), 
           "Average response time should be <50μs");
}

#[tokio::test]
async fn test_concurrent_client_handling() {
    // Test handling multiple concurrent clients
    let mut clients = Vec::new();
    
    for i in 0..5 {
        let mut fixture = MCPServerTestFixture::new().await;
        fixture.connect().await.unwrap();
        
        // Initialize each client
        let response = fixture.send_request("initialize", json!({
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {
                "name": format!("test-client-{}", i),
                "version": "1.0.0"
            }
        })).await.unwrap();
        
        assert!(response.error.is_none(), "Client {} initialize should not error", i);
        clients.push(fixture);
    }
    
    // Send concurrent requests from all clients
    let mut tasks = Vec::new();
    
    for (i, mut client) in clients.into_iter().enumerate() {
        let task = tokio::spawn(async move {
            // Each client sends multiple requests
            for j in 0..10 {
                let response = client.send_request("ping", json!({})).await.unwrap();
                assert!(response.error.is_none(), 
                       "Client {} request {} should not error", i, j);
            }
            i
        });
        tasks.push(task);
    }
    
    // Wait for all clients to complete
    for task in tasks {
        let client_id = task.await.unwrap();
        println!("Client {} completed successfully", client_id);
    }
}

#[tokio::test]
async fn test_mcp_spec_compliance() {
    let mut fixture = MCPServerTestFixture::new().await;
    fixture.connect().await.unwrap();
    
    // Test MCP spec v2024-11-05 compliance
    
    // 1. Initialize must support required fields
    let response = fixture.send_request("initialize", json!({
        "protocolVersion": "2024-11-05",
        "capabilities": {
            "roots": {
                "listChanged": false
            },
            "sampling": {}
        },
        "clientInfo": {
            "name": "compliance-test",
            "version": "1.0.0"
        }
    })).await.unwrap();
    
    assert!(response.error.is_none(), "Initialize should not error");
    let result = response.result.unwrap();
    
    // Server must respond with protocol version
    assert_eq!(result["protocolVersion"], "2024-11-05");
    assert!(result["capabilities"].is_object());
    assert!(result["serverInfo"].is_object());
    
    // 2. All required methods must be available
    let required_methods = [
        "initialize",
        "resources/list",
        "resources/read", 
        "tools/list",
        "tools/call",
        "prompts/list",
        "prompts/get",
        "completion/complete",
        "logging/setLevel",
        "ping"
    ];
    
    for method in required_methods {
        // Each method should at least not return "method not found"
        let response = fixture.send_request(method, json!({})).await.unwrap();
        if let Some(error) = response.error {
            assert_ne!(error.code, -32601, 
                      "Required method '{}' should exist", method);
        }
    }
    
    // 3. Error responses must follow JSON-RPC 2.0 spec
    let response = fixture.send_request("nonexistent_method", json!({})).await.unwrap();
    assert!(response.error.is_some());
    
    let error = response.error.unwrap();
    assert_eq!(error.code, -32601); // Method not found
    assert!(!error.message.is_empty());
    
    // 4. All responses must have jsonrpc: "2.0"
    assert_eq!(response.jsonrpc, "2.0");
}