#!/usr/bin/env python3
"""
FreqTrade Integration Example for Parasitic PairList
Demonstrates how to use the parasitic organism system with FreqTrade
"""

import json
import asyncio
import websockets
from datetime import datetime
from typing import Dict, List, Any
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ParasiticFreqTradeClient:
    """
    Client for integrating FreqTrade with CWTS Ultra parasitic system
    """
    
    def __init__(self, ws_url: str = "ws://localhost:3001"):
        self.ws_url = ws_url
        self.ws = None
        self.organism_id = None
        self.infected_pairs = []
        
    async def connect(self):
        """Connect to parasitic MCP server"""
        try:
            self.ws = await websockets.connect(self.ws_url)
            logger.info(f"Connected to parasitic system at {self.ws_url}")
            
            # Start listening for events
            asyncio.create_task(self._listen_events())
            
        except Exception as e:
            logger.error(f"Failed to connect: {e}")
            raise
            
    async def _listen_events(self):
        """Listen for parasitic system events"""
        try:
            async for message in self.ws:
                event = json.loads(message)
                await self._handle_event(event)
        except Exception as e:
            logger.error(f"Event listener error: {e}")
            
    async def _handle_event(self, event: Dict):
        """Handle parasitic system events"""
        event_type = event.get("type")
        
        if event_type == "OrganismSpawned":
            logger.info(f"Organism spawned: {event['data']['organism_id']}")
            
        elif event_type == "PairInfected":
            pair_id = event['data']['pair_id']
            self.infected_pairs.append(pair_id)
            logger.info(f"Pair infected: {pair_id}")
            
        elif event_type == "InfectionEnded":
            pair_id = event['data']['pair_id']
            profit = event['data'].get('profit_percentage', 0)
            logger.info(f"Infection ended for {pair_id}: {profit:.2f}% profit")
            if pair_id in self.infected_pairs:
                self.infected_pairs.remove(pair_id)
                
        elif event_type == "OrganismEvolved":
            logger.info(f"Organism evolved with new genetics")
            
    async def spawn_organism(self, organism_type: str, genetics: Dict = None) -> str:
        """Spawn a new parasitic organism"""
        request = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {
                "name": "parasitic_select",
                "arguments": {
                    "organism_type": organism_type,
                    "genetics": genetics or {
                        "aggression": 0.5,
                        "adaptability": 0.8,
                        "efficiency": 0.7,
                        "resilience": 0.6,
                        "reaction_speed": 0.8,
                        "risk_tolerance": 0.5,
                        "cooperation": 0.3,
                        "stealth": 0.7
                    }
                }
            }
        }
        
        await self.ws.send(json.dumps(request))
        response = await self.ws.recv()
        result = json.loads(response)
        
        if "result" in result:
            self.organism_id = result["result"]["organism_id"]
            logger.info(f"Spawned {organism_type} organism: {self.organism_id}")
            return self.organism_id
        else:
            raise Exception(f"Failed to spawn organism: {result}")
            
    async def analyze_pairs(self, pairs: List[str]) -> List[Dict]:
        """Analyze trading pairs for vulnerability"""
        vulnerable_pairs = []
        
        for pair in pairs:
            request = {
                "jsonrpc": "2.0",
                "id": 2,
                "method": "tools/call",
                "params": {
                    "name": "parasitic_analyze",
                    "arguments": {
                        "pair_id": pair,
                        "depth": "full"
                    }
                }
            }
            
            await self.ws.send(json.dumps(request))
            response = await self.ws.recv()
            result = json.loads(response)
            
            if "result" in result:
                analysis = result["result"]
                if analysis["vulnerability_score"] > 0.6:
                    vulnerable_pairs.append({
                        "pair": pair,
                        "vulnerability": analysis["vulnerability_score"],
                        "best_organism": analysis["recommended_organism"],
                        "infection_probability": analysis["infection_probability"]
                    })
                    
        # Sort by vulnerability
        vulnerable_pairs.sort(key=lambda x: x["vulnerability"], reverse=True)
        return vulnerable_pairs
        
    async def infect_pair(self, pair: str) -> Dict:
        """Infect a trading pair with parasitic organism"""
        if not self.organism_id:
            raise Exception("No organism spawned")
            
        request = {
            "jsonrpc": "2.0",
            "id": 3,
            "method": "tools/call",
            "params": {
                "name": "parasitic_infect",
                "arguments": {
                    "pair_id": pair,
                    "organism_id": self.organism_id
                }
            }
        }
        
        await self.ws.send(json.dumps(request))
        response = await self.ws.recv()
        result = json.loads(response)
        
        if "result" in result:
            logger.info(f"Successfully infected {pair}")
            return result["result"]
        else:
            raise Exception(f"Failed to infect {pair}: {result}")
            
    async def trigger_evolution(self, parameters: Dict = None) -> Dict:
        """Trigger organism evolution"""
        request = {
            "jsonrpc": "2.0",
            "id": 4,
            "method": "tools/call",
            "params": {
                "name": "parasitic_evolve",
                "arguments": {
                    "organism_id": self.organism_id,
                    "parameters": parameters or {
                        "mutation_rate": 0.1,
                        "selection_pressure": 0.7,
                        "generations": 10
                    }
                }
            }
        }
        
        await self.ws.send(json.dumps(request))
        response = await self.ws.recv()
        result = json.loads(response)
        
        if "result" in result:
            logger.info("Evolution completed")
            return result["result"]
        else:
            raise Exception(f"Evolution failed: {result}")
            
    async def get_infected_pairs(self) -> List[str]:
        """Get list of currently infected pairs"""
        request = {
            "jsonrpc": "2.0",
            "id": 5,
            "method": "resources/read",
            "params": {
                "uri": "parasitic://pairs/infected"
            }
        }
        
        await self.ws.send(json.dumps(request))
        response = await self.ws.recv()
        result = json.loads(response)
        
        if "result" in result:
            return result["result"]["infected_pairs"]
        else:
            return []
            
    async def get_evolution_status(self) -> Dict:
        """Get evolution status and metrics"""
        request = {
            "jsonrpc": "2.0",
            "id": 6,
            "method": "resources/read",
            "params": {
                "uri": "parasitic://evolution/status"
            }
        }
        
        await self.ws.send(json.dumps(request))
        response = await self.ws.recv()
        result = json.loads(response)
        
        if "result" in result:
            return result["result"]
        else:
            return {}


async def main():
    """
    Example usage of parasitic FreqTrade integration
    """
    # Initialize client
    client = ParasiticFreqTradeClient()
    await client.connect()
    
    # Spawn a Cuckoo organism with custom genetics
    organism_id = await client.spawn_organism(
        "cuckoo",
        genetics={
            "aggression": 0.3,      # Low aggression for stealth
            "adaptability": 0.9,    # High adaptability 
            "efficiency": 0.8,      # High efficiency
            "resilience": 0.7,      # Good resilience
            "reaction_speed": 0.9,  # Fast reactions
            "risk_tolerance": 0.4,  # Moderate risk
            "cooperation": 0.2,     # Low cooperation (parasitic)
            "stealth": 0.95         # Maximum stealth
        }
    )
    
    # Analyze some trading pairs
    test_pairs = ["BTC/USDT", "ETH/USDT", "SOL/USDT", "MATIC/USDT", "DOT/USDT"]
    vulnerable_pairs = await client.analyze_pairs(test_pairs)
    
    logger.info("\n=== Vulnerability Analysis ===")
    for pair_data in vulnerable_pairs:
        logger.info(f"{pair_data['pair']}: "
                   f"Vulnerability={pair_data['vulnerability']:.2f}, "
                   f"Best={pair_data['best_organism']}, "
                   f"Infection Prob={pair_data['infection_probability']:.2f}")
    
    # Infect the most vulnerable pairs
    if vulnerable_pairs:
        for pair_data in vulnerable_pairs[:3]:  # Infect top 3
            await client.infect_pair(pair_data['pair'])
            await asyncio.sleep(0.5)  # Small delay between infections
    
    # Check infected pairs
    infected = await client.get_infected_pairs()
    logger.info(f"\nCurrently infected pairs: {infected}")
    
    # Wait for some activity
    await asyncio.sleep(5)
    
    # Trigger evolution based on performance
    evolution_result = await client.trigger_evolution({
        "mutation_rate": 0.15,
        "selection_pressure": 0.8,
        "generations": 20
    })
    
    # Get evolution status
    evolution_status = await client.get_evolution_status()
    logger.info(f"\nEvolution Status: {json.dumps(evolution_status, indent=2)}")
    
    # Keep running to receive events
    logger.info("\nListening for parasitic events... (Ctrl+C to stop)")
    try:
        await asyncio.Future()  # Run forever
    except KeyboardInterrupt:
        logger.info("Shutting down...")


if __name__ == "__main__":
    asyncio.run(main())