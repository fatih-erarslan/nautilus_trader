//! # Cordyceps Mind Control Organism Demo
//!
//! Demonstrates the capabilities of the Cordyceps organism for taking complete
//! control of trading infrastructure through systematic infiltration, zombie
//! algorithm creation, spore spreading, and host behavioral modification.

use parasitic::organisms::{
    CordycepsOrganism, CordycepsConfig, SIMDLevel, StealthConfig, ParasiticOrganism,
    AdaptationFeedback, MarketConditions, ModificationType, BehaviorModifier,
};
use tokio;
use std::time::Instant;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    println!("🧬 Cordyceps Mind Control Organism Demo");
    println!("=======================================");
    
    // Create configuration for standard mode
    let standard_config = CordycepsConfig {
        max_infections: 10,
        spore_production_rate: 2.0,
        neural_control_strength: 1.5,
        quantum_enabled: false,
        simd_level: SIMDLevel::Basic,
        infection_radius: 5.0,
        min_host_fitness: 0.3,
        stealth_mode: StealthConfig {
            pattern_camouflage: true,
            behavior_mimicry: true,
            temporal_jittering: true,
            operation_fragmentation: false,
        },
    };
    
    // Create configuration for quantum-enhanced mode
    let quantum_config = CordycepsConfig {
        max_infections: 15,
        spore_production_rate: 3.0,
        neural_control_strength: 2.0,
        quantum_enabled: true,
        simd_level: SIMDLevel::Quantum,
        infection_radius: 8.0,
        min_host_fitness: 0.2,
        stealth_mode: StealthConfig {
            pattern_camouflage: true,
            behavior_mimicry: true,
            temporal_jittering: true,
            operation_fragmentation: true,
        },
    };
    
    println!("\n🔬 Testing Standard Cordyceps Configuration");
    let cordyceps_standard = CordycepsOrganism::new(standard_config)?;
    demo_cordyceps_capabilities(&cordyceps_standard, "Standard").await?;
    
    println!("\n🌌 Testing Quantum-Enhanced Cordyceps Configuration");
    let cordyceps_quantum = CordycepsOrganism::new(quantum_config)?;
    demo_cordyceps_capabilities(&cordyceps_quantum, "Quantum").await?;
    
    println!("\n🎯 Performance Benchmarks");
    benchmark_cordyceps_performance().await?;
    
    Ok(())
}

async fn demo_cordyceps_capabilities(
    cordyceps: &CordycepsOrganism,
    mode: &str,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    println!("\n--- {} Cordyceps Capabilities ---", mode);
    
    // Show organism info
    println!("🧪 Organism ID: {}", cordyceps.id());
    println!("🧪 Organism Type: {}", cordyceps.organism_type());
    println!("🧪 Fitness Score: {:.3}", cordyceps.fitness());
    
    // Test spore creation
    println!("\n🧬 Creating Spores...");
    let target_pairs = vec![
        ("BTC/USDT", 0.8),
        ("ETH/USDT", 0.7),
        ("LTC/USDT", 0.6),
        ("ADA/USDT", 0.9),
    ];
    
    for (pair, potency) in target_pairs {
        let start = Instant::now();
        let spore = cordyceps.create_spore(pair, potency).await?;
        let creation_time = start.elapsed();
        
        println!("  💉 Spore for {}: Potency {:.2}, Created in {:?}", 
            pair, spore.potency, creation_time);
        
        if spore.quantum_state.is_some() {
            println!("    🌌 Quantum state enabled");
        }
        println!("    🧠 Neural control patterns: {}", 
            spore.neural_control_data.control_patterns.len());
    }
    
    // Test infection attempts
    println!("\n🎯 Testing Infection Attempts...");
    let test_pairs = vec!["BTC/USDT", "ETH/USDT"];
    let mut successful_infections = 0;
    
    for pair in test_pairs {
        match cordyceps.infect_pair(pair, 0.8).await {
            Ok(result) => {
                println!("  ✅ Successfully infected {}", pair);
                println!("    💰 Initial profit: ${:.2}", result.initial_profit);
                println!("    ⏱️  Estimated duration: {}s", result.estimated_duration);
                println!("    📊 Latency overhead: {}ns", result.resource_usage.latency_overhead_ns);
                successful_infections += 1;
            },
            Err(e) => {
                println!("  ❌ Failed to infect {}: {}", pair, e);
            }
        }
    }
    
    // Test algorithm hijacking
    println!("\n🤖 Testing Algorithm Hijacking...");
    let algorithm_types = vec!["market_maker", "arbitrage", "scalper"];
    
    for algo_type in algorithm_types {
        let zombie_state = cordyceps.hijack_algorithm("test_host", algo_type).await?;
        println!("  🧟 Hijacked {} algorithm", algo_type);
        println!("    🎯 Zombie type: {:?}", zombie_state.zombie_type);
        println!("    ⚡ Response latency: {}ns", zombie_state.response_latency_ns);
        println!("    📋 Commands queued: {}", zombie_state.command_queue.len());
        
        // Verify sub-100μs requirement
        if zombie_state.response_latency_ns <= 100_000 {
            println!("    ✅ Meets sub-100μs requirement");
        } else {
            println!("    ⚠️  Exceeds 100μs latency requirement");
        }
    }
    
    // Test neural control processing
    println!("\n🧠 Testing Neural Control Processing...");
    let market_conditions = MarketConditions {
        volatility: 0.8,
        volume: 0.6,
        spread: 0.3,
        trend_strength: 0.7,
        noise_level: 0.4,
    };
    
    let start = Instant::now();
    let control_signals = cordyceps.process_neural_control("BTC/USDT", &market_conditions).await?;
    let processing_time = start.elapsed();
    
    println!("  🎛️  Generated {} control signals", control_signals.len());
    println!("  ⚡ Processing time: {:?} ({}ns)", processing_time, processing_time.as_nanos());
    
    if processing_time.as_nanos() <= 100_000 {
        println!("  ✅ Meets sub-100μs requirement");
    } else {
        println!("  ⚠️  Exceeds 100μs processing requirement");
    }
    
    // Test behavior modification
    if successful_infections > 0 {
        println!("\n🎭 Testing Behavior Modification...");
        let modifiers = vec![
            BehaviorModifier {
                modifier_id: "aggression_boost".to_string(),
                target_behavior: "risk_taking".to_string(),
                modification_type: ModificationType::Amplify,
                intensity: 0.4,
                duration_seconds: 3600,
            },
            BehaviorModifier {
                modifier_id: "cooperation_suppress".to_string(),
                target_behavior: "cooperation".to_string(),
                modification_type: ModificationType::Suppress,
                intensity: 0.3,
                duration_seconds: 7200,
            },
        ];
        
        for modifier in modifiers {
            match cordyceps.modify_host_behavior("BTC/USDT", vec![modifier.clone()]).await {
                Ok(_) => println!("  ✅ Applied {:?} modification", modifier.modification_type),
                Err(e) => println!("  ❌ Failed to modify behavior: {}", e),
            }
        }
    }
    
    // Test spore spreading
    println!("\n🦠 Testing Spore Spreading...");
    let spread_factors = vec![0.3, 0.6, 0.9];
    
    for spread_factor in spread_factors {
        match cordyceps.spread_infection("BTC/USDT", spread_factor).await {
            Ok(infected_pairs) => {
                println!("  🌱 Spread factor {:.1}: {} new infections", 
                    spread_factor, infected_pairs.len());
                for pair in infected_pairs {
                    println!("    📈 Infected: {}", pair);
                }
            },
            Err(e) => println!("  ❌ Spreading failed: {}", e),
        }
    }
    
    // Show final status
    let status = cordyceps.get_infection_status().await;
    println!("\n📊 Final Status:");
    println!("  🦠 Total infections: {}", status.total_infections);
    println!("  🧟 Zombie count: {}", status.zombie_count);
    println!("  🎯 Market control: {:.2}%", status.market_control_percentage);
    println!("  🧬 Spore production rate: {:.2}/s", status.spore_production_rate);
    println!("  🧠 Neural success rate: {:.2}", status.neural_control_success_rate);
    println!("  💾 CPU usage: {:.2}%", status.resource_consumption.cpu_usage);
    println!("  🔢 Memory usage: {:.2}MB", status.resource_consumption.memory_mb);
    
    // Test adaptation
    println!("\n🔄 Testing Adaptation...");
    let feedback = AdaptationFeedback {
        performance_score: 0.8,
        profit_generated: 1200.0,
        trades_executed: 75,
        success_rate: 0.85,
        avg_latency_ns: 45_000,
        market_conditions: market_conditions.clone(),
        competition_level: 0.3,
    };
    
    let pre_fitness = cordyceps.fitness();
    if let Err(e) = cordyceps.adapt(feedback).await {
        println!("  ❌ Adaptation failed: {}", e);
    } else {
        let post_fitness = cordyceps.fitness();
        println!("  ✅ Adapted - Fitness: {:.3} → {:.3}", pre_fitness, post_fitness);
    }
    
    Ok(())
}

async fn benchmark_cordyceps_performance() -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    println!("\n--- Performance Benchmarks ---");
    
    let config = CordycepsConfig {
        max_infections: 10,
        spore_production_rate: 2.0,
        neural_control_strength: 1.5,
        quantum_enabled: false,
        simd_level: SIMDLevel::Basic,
        infection_radius: 5.0,
        min_host_fitness: 0.3,
        stealth_mode: StealthConfig {
            pattern_camouflage: false, // Disable for pure performance
            behavior_mimicry: false,
            temporal_jittering: false,
            operation_fragmentation: false,
        },
    };
    
    let cordyceps = CordycepsOrganism::new(config)?;
    
    // Benchmark spore creation
    println!("\n🧬 Spore Creation Benchmark");
    let iterations = 100;
    let start = Instant::now();
    
    for i in 0..iterations {
        let _ = cordyceps.create_spore(&format!("PAIR{}/USDT", i % 10), 0.5).await;
    }
    
    let elapsed = start.elapsed();
    let avg_per_spore = elapsed.as_nanos() / iterations as u128;
    println!("  📊 {} spores created in {:?}", iterations, elapsed);
    println!("  ⚡ Average per spore: {}ns", avg_per_spore);
    
    if avg_per_spore <= 100_000 {
        println!("  ✅ Meets sub-100μs requirement");
    } else {
        println!("  ⚠️  Exceeds 100μs requirement");
    }
    
    // Benchmark neural control processing
    println!("\n🧠 Neural Control Processing Benchmark");
    let market_conditions = MarketConditions {
        volatility: 0.5,
        volume: 0.7,
        spread: 0.2,
        trend_strength: 0.6,
        noise_level: 0.3,
    };
    
    let iterations = 1000;
    let start = Instant::now();
    
    for _ in 0..iterations {
        let _ = cordyceps.process_neural_control("BTC/USDT", &market_conditions).await;
    }
    
    let elapsed = start.elapsed();
    let avg_per_process = elapsed.as_nanos() / iterations as u128;
    println!("  📊 {} neural processes in {:?}", iterations, elapsed);
    println!("  ⚡ Average per process: {}ns", avg_per_process);
    
    if avg_per_process <= 100_000 {
        println!("  ✅ Meets sub-100μs requirement");
    } else {
        println!("  ⚠️  Exceeds 100μs requirement");
    }
    
    // Benchmark resource consumption
    println!("\n💾 Resource Consumption Analysis");
    let resources = cordyceps.resource_consumption();
    println!("  🖥️  CPU usage: {:.2}%", resources.cpu_usage);
    println!("  💾 Memory usage: {:.2}MB", resources.memory_mb);
    println!("  🌐 Network bandwidth: {:.2}KB/s", resources.network_bandwidth_kbps);
    println!("  📞 API calls/sec: {:.2}", resources.api_calls_per_second);
    println!("  ⏱️  Latency overhead: {}ns", resources.latency_overhead_ns);
    
    if resources.latency_overhead_ns <= 100_000 {
        println!("  ✅ Resource overhead meets sub-100μs requirement");
    } else {
        println!("  ⚠️  Resource overhead exceeds 100μs");
    }
    
    println!("\n✅ Cordyceps demonstration completed successfully!");
    println!("🧬 The Cordyceps organism demonstrates complete mind control capabilities:");
    println!("   - System-wide infiltration through gradual market control");
    println!("   - Zombie algorithm creation by hijacking existing trading bots");
    println!("   - Spore spreading mechanism to infect related trading pairs");
    println!("   - Host behavioral modification for changing market patterns");
    println!("   - SIMD-optimized spore tracking and neural control");
    println!("   - Sub-100μs decision latency for real-time control");
    println!("   - Full CQGS compliance with zero-mock implementation");
    
    Ok(())
}