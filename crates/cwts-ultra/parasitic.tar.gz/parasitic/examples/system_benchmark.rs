//! System Performance Benchmark
//! 
//! Comprehensive benchmarking suite for the parasitic trading system.
//! Tests quantum pattern matching, SIMD operations, throughput, and scalability.
//! 
//! Run with: cargo run --example system_benchmark --release --features ultra-performance

use cwts_parasitic::*;
use cwts_parasitic::organisms::cuckoo::*;
use std::time::{Duration, Instant};
use std::sync::Arc;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    println!("⚡ CWTS Ultra - Parasitic System Performance Benchmark");
    println!("═══════════════════════════════════════════════════════════");
    
    // System information
    println!("🖥️  System Information:");
    println!("   SIMD AVX2 Support: {}", is_x86_feature_detected!("avx2"));
    println!("   SIMD AVX512F Support: {}", is_x86_feature_detected!("avx512f"));
    println!("   CPU Cores: {}", num_cpus::get());
    println!();
    
    // Benchmark 1: Quantum Pattern Similarity
    benchmark_quantum_patterns().await?;
    
    // Benchmark 2: System Throughput
    benchmark_system_throughput().await?;
    
    // Benchmark 3: Concurrent Operations
    benchmark_concurrent_operations().await?;
    
    // Benchmark 4: Memory Efficiency
    benchmark_memory_efficiency().await?;
    
    // Benchmark 5: Strategy Scaling
    benchmark_strategy_scaling().await?;
    
    // Benchmark 6: High-Frequency Trading Simulation
    benchmark_hft_simulation().await?;
    
    println!("🎯 All benchmarks completed successfully!");
    
    Ok(())
}

async fn benchmark_quantum_patterns() -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    println!("🧮 Benchmark 1: Quantum Pattern Matching");
    println!("─────────────────────────────────────────────────");
    
    // Create test patterns
    let mut pattern1 = QuantumPatternSignature::new();
    let mut pattern2 = QuantumPatternSignature::new();
    
    // Fill with complex mathematical patterns
    for i in 0..32 {
        let t = i as f64 * 0.1;
        pattern1.frequency_spectrum[i] = (t.sin() * t.cos() + (t * 2.0).sin() * 0.5).abs();
        pattern2.frequency_spectrum[i] = ((t + 0.1).sin() * (t + 0.1).cos() + ((t + 0.1) * 2.0).sin() * 0.5).abs();
    }
    
    for i in 0..16 {
        let t = i as f64 * 0.05;
        pattern1.phase_relationships[i] = (t * 3.0).sin().atan();
        pattern2.phase_relationships[i] = ((t + 0.05) * 3.0).sin().atan();
    }
    
    pattern1.quantum_entanglement_score = 0.456789;
    pattern2.quantum_entanglement_score = 0.467890;
    pattern1.amplitude_coherence = 0.789012;
    pattern2.amplitude_coherence = 0.798123;
    
    // Benchmark scalar implementation
    let iterations = 50_000;
    println!("   Testing {} iterations...", iterations);
    
    let start = Instant::now();
    let mut scalar_total = 0.0;
    for _ in 0..iterations {
        scalar_total += pattern1.scalar_similarity(&pattern2);
    }
    let scalar_duration = start.elapsed();
    let scalar_ops_per_sec = iterations as f64 / scalar_duration.as_secs_f64();
    
    println!("   📊 Scalar Results:");
    println!("      Time: {:?}", scalar_duration);
    println!("      Ops/sec: {:.0}", scalar_ops_per_sec);
    println!("      Avg similarity: {:.6}", scalar_total / iterations as f64);
    println!("      Nanosec/op: {:.2}", scalar_duration.as_nanos() as f64 / iterations as f64);
    
    // Benchmark SIMD implementation
    let start = Instant::now();
    let mut simd_total = 0.0;
    for _ in 0..iterations {
        simd_total += pattern1.quantum_similarity(&pattern2);
    }
    let simd_duration = start.elapsed();
    let simd_ops_per_sec = iterations as f64 / simd_duration.as_secs_f64();
    
    println!("   🚀 SIMD/Optimized Results:");
    println!("      Time: {:?}", simd_duration);
    println!("      Ops/sec: {:.0}", simd_ops_per_sec);
    println!("      Avg similarity: {:.6}", simd_total / iterations as f64);
    println!("      Nanosec/op: {:.2}", simd_duration.as_nanos() as f64 / iterations as f64);
    
    let speedup = simd_ops_per_sec / scalar_ops_per_sec;
    println!("   ⚡ Performance Improvement: {:.2}x", speedup);
    
    if speedup > 1.1 {
        println!("   ✅ SIMD optimization effective!");
    } else if speedup > 0.9 {
        println!("   ✅ Performance maintained (no regression)");
    } else {
        println!("   ⚠️ SIMD implementation may need optimization");
    }
    
    println!();
    Ok(())
}

async fn benchmark_system_throughput() -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    println!("🔥 Benchmark 2: System Throughput");
    println!("─────────────────────────────────────────────────");
    
    let system = ParasiticTradingSystem::new_default();
    system.activate().await?;
    
    // Throughput test: mixed operations
    let test_duration = Duration::from_secs(3);
    let start = Instant::now();
    let mut operations = 0u64;
    let mut status_ops = 0u64;
    let mut metrics_ops = 0u64;
    
    println!("   Running mixed operations for {:?}...", test_duration);
    
    while start.elapsed() < test_duration {
        let op = operations % 3;
        
        match op {
            0 => {
                let _ = system.get_status().await;
                status_ops += 1;
            },
            1 => {
                let _ = system.get_performance_metrics().await;
                metrics_ops += 1;
            },
            2 => {
                let _ = system.is_active();
            },
            _ => unreachable!(),
        }
        
        operations += 1;
        
        // Prevent blocking the runtime
        if operations % 1000 == 0 {
            tokio::task::yield_now().await;
        }
    }
    
    let actual_duration = start.elapsed();
    let total_throughput = operations as f64 / actual_duration.as_secs_f64();
    
    println!("   📊 Throughput Results:");
    println!("      Total operations: {}", operations);
    println!("      Actual duration: {:?}", actual_duration);
    println!("      Total throughput: {:.0} ops/sec", total_throughput);
    println!("      Status operations: {} ({:.0} ops/sec)", status_ops, status_ops as f64 / actual_duration.as_secs_f64());
    println!("      Metrics operations: {} ({:.0} ops/sec)", metrics_ops, metrics_ops as f64 / actual_duration.as_secs_f64());
    
    if total_throughput > 10_000.0 {
        println!("   ✅ Excellent throughput for HFT applications");
    } else if total_throughput > 1_000.0 {
        println!("   ✅ Good throughput for regular trading");
    } else {
        println!("   ⚠️ Throughput may be insufficient for high-frequency trading");
    }
    
    system.deactivate().await?;
    println!();
    Ok(())
}

async fn benchmark_concurrent_operations() -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    println!("🔄 Benchmark 3: Concurrent Operations");
    println!("─────────────────────────────────────────────────");
    
    let system = Arc::new(ParasiticTradingSystem::new_default());
    system.activate().await?;
    
    // Test different concurrency levels
    let concurrency_levels = [1, 2, 4, 8, 16, 32];
    
    for &concurrency in &concurrency_levels {
        println!("   Testing with {} concurrent tasks...", concurrency);
        
        let start = Instant::now();
        let mut handles = vec![];
        
        for i in 0..concurrency {
            let system_clone = system.clone();
            let handle = tokio::spawn(async move {
                let mut ops_count = 0;
                let task_start = Instant::now();
                
                while task_start.elapsed() < Duration::from_secs(1) {
                    match i % 2 {
                        0 => { let _ = system_clone.get_status().await; },
                        1 => { let _ = system_clone.get_performance_metrics().await; },
                        _ => unreachable!(),
                    }
                    ops_count += 1;
                    
                    if ops_count % 100 == 0 {
                        tokio::task::yield_now().await;
                    }
                }
                
                ops_count
            });
            handles.push(handle);
        }
        
        let results = futures::future::join_all(handles).await;
        let duration = start.elapsed();
        
        let total_ops: u64 = results.into_iter().map(|r| r.unwrap()).sum();
        let throughput = total_ops as f64 / duration.as_secs_f64();
        
        println!("      Duration: {:?}", duration);
        println!("      Total ops: {}", total_ops);
        println!("      Throughput: {:.0} ops/sec", throughput);
        
        // Calculate efficiency (throughput per thread)
        let efficiency = throughput / concurrency as f64;
        println!("      Efficiency: {:.0} ops/sec/thread", efficiency);
    }
    
    system.deactivate().await?;
    println!("   ✅ Concurrency scaling analysis complete");
    println!();
    Ok(())
}

async fn benchmark_memory_efficiency() -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    println!("💾 Benchmark 4: Memory Efficiency");
    println!("─────────────────────────────────────────────────");
    
    use std::mem::size_of;
    
    // Analyze struct sizes
    println!("   📏 Data Structure Sizes:");
    println!("      QuantumPatternSignature: {} bytes", size_of::<QuantumPatternSignature>());
    println!("      HostTradingPair: {} bytes", size_of::<HostTradingPair>());
    println!("      ParasiticEgg: {} bytes", size_of::<ParasiticEgg>());
    println!("      CuckooStats: {} bytes", size_of::<CuckooStats>());
    println!("      SystemMetrics: {} bytes", size_of::<SystemMetrics>());
    println!();
    
    // Test memory scaling
    let cuckoo = CuckooStrategy::new();
    
    println!("   🧮 Memory Scaling Test:");
    
    // Test with different numbers of hosts
    let host_counts = [10, 100, 1000];
    
    for &host_count in &host_counts {
        let start = Instant::now();
        
        {
            let mut host_db = cuckoo.host_database.write().await;
            
            for i in 0..host_count {
                let mut host = HostTradingPair::new(
                    format!("SCALE{}USDT", i),
                    format!("SCALE{}", i),
                    "USDT".to_string()
                );
                
                // Fill with realistic data
                for j in 0..HOST_PATTERN_WINDOW {
                    let price = 100.0 + (i as f64) * 0.1 + (j as f64) * 0.01;
                    let volume = 1000.0 + (i as f64) * 10.0 + (j as f64) * 1.0;
                    host.price_history.push_back(price);
                    host.volume_trend.push_back(volume);
                }
                
                host.success_rate = 0.7 + (i as f64 / host_count as f64) * 0.2;
                host_db.insert(format!("SCALE{}USDT", i), host);
            }
        } // Release lock
        
        let setup_time = start.elapsed();
        
        // Test access performance
        let start = Instant::now();
        let host_db = cuckoo.host_database.read().await;
        let _count = host_db.len();
        drop(host_db);
        let access_time = start.elapsed();
        
        println!("      {} hosts:", host_count);
        println!("         Setup time: {:?}", setup_time);
        println!("         Access time: {:?}", access_time);
        println!("         Setup time per host: {:?}", setup_time / host_count as u32);
        
        // Estimate memory usage (simplified)
        let estimated_memory = host_count * size_of::<HostTradingPair>() +
                              host_count * HOST_PATTERN_WINDOW * (size_of::<f64>() * 2); // price + volume
        println!("         Estimated memory: {} KB", estimated_memory / 1024);
    }
    
    println!("   ✅ Memory efficiency analysis complete");
    println!();
    Ok(())
}

async fn benchmark_strategy_scaling() -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    println!("📈 Benchmark 5: Strategy Scaling");
    println!("─────────────────────────────────────────────────");
    
    // Test system with different numbers of concurrent strategies
    let strategy_counts = [1, 2, 4, 8];
    
    for &strategy_count in &strategy_counts {
        println!("   Testing with {} concurrent strategies...", strategy_count);
        
        let config = ParasiticConfig {
            max_concurrent_strategies: strategy_count,
            quantum_threads: 4,
            ..ParasiticConfig::default()
        };
        
        let system = ParasiticTradingSystem::new(config);
        
        let start = Instant::now();
        system.activate().await?;
        let activation_time = start.elapsed();
        
        // Add strategies up to the limit
        let add_start = Instant::now();
        for _ in 1..strategy_count { // First strategy added during activation
            let _ = system.add_strategy(ParasiteType::Cuckoo).await;
        }
        let add_time = add_start.elapsed();
        
        // Test performance with all strategies
        let perf_start = Instant::now();
        let mut total_ops = 0;
        
        for _ in 0..100 {
            let _ = system.get_performance_metrics().await;
            let _ = system.get_status().await;
            total_ops += 2;
        }
        
        let perf_time = perf_start.elapsed();
        let ops_per_sec = total_ops as f64 / perf_time.as_secs_f64();
        
        // Cleanup
        let deactivate_start = Instant::now();
        system.deactivate().await?;
        let deactivate_time = deactivate_start.elapsed();
        
        println!("      Activation time: {:?}", activation_time);
        println!("      Strategy addition time: {:?}", add_time);
        println!("      Performance (100 mixed ops): {:?} ({:.0} ops/sec)", perf_time, ops_per_sec);
        println!("      Deactivation time: {:?}", deactivate_time);
        
        // Check if scaling is reasonable
        let total_lifecycle = activation_time + add_time + deactivate_time;
        println!("      Total lifecycle: {:?}", total_lifecycle);
    }
    
    println!("   ✅ Strategy scaling analysis complete");
    println!();
    Ok(())
}

async fn benchmark_hft_simulation() -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    println!("⚡ Benchmark 6: High-Frequency Trading Simulation");
    println!("─────────────────────────────────────────────────");
    
    // Set up high-performance configuration
    let config = ParasiticConfig {
        max_concurrent_strategies: 8,
        quantum_threads: 8,
        simd_level: 2, // AVX512
        risk_tolerance: 0.6,
        aggression_factor: 3.0,
        quantum_coherence: true,
        enabled_parasites: vec![ParasiteType::Cuckoo],
    };
    
    let system = Arc::new(ParasiticTradingSystem::new(config));
    system.activate().await?;
    
    println!("   🚀 Simulating high-frequency trading conditions...");
    
    // Simulate market data updates (high frequency)
    let market_data_handle = {
        let system_clone = system.clone();
        tokio::spawn(async move {
            let mut updates = 0u64;
            let start = Instant::now();
            
            while start.elapsed() < Duration::from_secs(5) {
                // Simulate rapid market data processing
                let _ = system_clone.get_status().await;
                updates += 1;
                
                // High-frequency: minimal delay
                tokio::time::sleep(Duration::from_micros(100)).await;
            }
            
            updates
        })
    };
    
    // Simulate order management (high frequency)
    let order_mgmt_handle = {
        let system_clone = system.clone();
        tokio::spawn(async move {
            let mut orders = 0u64;
            let start = Instant::now();
            
            while start.elapsed() < Duration::from_secs(5) {
                // Simulate order-related metrics access
                let _ = system_clone.get_performance_metrics().await;
                orders += 1;
                
                // High-frequency: minimal delay
                tokio::time::sleep(Duration::from_micros(150)).await;
            }
            
            orders
        })
    };
    
    // Simulate risk management (medium frequency)
    let risk_mgmt_handle = {
        let system_clone = system.clone();
        tokio::spawn(async move {
            let mut risk_checks = 0u64;
            let start = Instant::now();
            
            while start.elapsed() < Duration::from_secs(5) {
                // Simulate risk checks
                let status = system_clone.get_status().await;
                if status["status"] == "active" {
                    risk_checks += 1;
                }
                
                // Medium frequency: moderate delay
                tokio::time::sleep(Duration::from_millis(1)).await;
            }
            
            risk_checks
        })
    };
    
    // Wait for all simulation tasks
    let (market_updates, order_operations, risk_checks) = 
        tokio::join!(market_data_handle, order_mgmt_handle, risk_mgmt_handle);
    
    let market_updates = market_updates.unwrap();
    let order_operations = order_operations.unwrap();
    let risk_checks = risk_checks.unwrap();
    
    println!("   📊 HFT Simulation Results (5 second test):");
    println!("      Market data updates: {} ({:.0}/sec)", market_updates, market_updates as f64 / 5.0);
    println!("      Order operations: {} ({:.0}/sec)", order_operations, order_operations as f64 / 5.0);
    println!("      Risk checks: {} ({:.0}/sec)", risk_checks, risk_checks as f64 / 5.0);
    
    let total_operations = market_updates + order_operations + risk_checks;
    println!("      Total operations: {} ({:.0}/sec)", total_operations, total_operations as f64 / 5.0);
    
    // Analyze final system state
    let final_metrics = system.get_performance_metrics().await;
    println!("   🎯 Final System State:");
    println!("      Hosts identified: {}", final_metrics.total_hosts_identified);
    println!("      Positions placed: {}", final_metrics.total_positions_placed);
    println!("      Win rate: {:.1}%", final_metrics.overall_win_rate * 100.0);
    println!("      Total profit: ${:.2}", final_metrics.total_profit);
    
    if total_operations as f64 / 5.0 > 5000.0 {
        println!("   ✅ System meets high-frequency trading requirements!");
    } else if total_operations as f64 / 5.0 > 1000.0 {
        println!("   ✅ System suitable for medium-frequency trading");
    } else {
        println!("   ⚠️ System may need optimization for high-frequency trading");
    }
    
    system.deactivate().await?;
    println!();
    Ok(())
}

// Helper function to get CPU count
mod num_cpus {
    pub fn get() -> usize {
        std::thread::available_parallelism().map(|n| n.get()).unwrap_or(1)
    }
}