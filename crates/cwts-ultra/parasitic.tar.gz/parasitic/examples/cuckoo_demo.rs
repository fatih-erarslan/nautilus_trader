//! Cuckoo Brood Parasitism Strategy Demonstration
//! 
//! This example demonstrates the quantum-enhanced Cuckoo strategy in action,
//! showing how it identifies profitable trading pairs, mimics their patterns,
//! injects parasitic positions, and eliminates competing signals.
//! 
//! Run with: cargo run --example cuckoo_demo --features ultra-performance

use cwts_parasitic::*;
use std::time::Duration;
use tokio::time::sleep;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    println!("🐣 CWTS Ultra - Cuckoo Brood Parasitism Strategy Demo");
    println!("═══════════════════════════════════════════════════════");
    
    // Create and configure the parasitic trading system
    let config = ParasiticConfig {
        max_concurrent_strategies: 3,
        quantum_threads: 4,
        simd_level: 2, // Use AVX512 if available
        risk_tolerance: 0.4, // Moderate risk
        aggression_factor: 2.0, // High aggression for demo
        quantum_coherence: true,
        enabled_parasites: vec![ParasiteType::Cuckoo],
    };
    
    println!("📋 Configuration:");
    println!("   Max concurrent strategies: {}", config.max_concurrent_strategies);
    println!("   Quantum threads: {}", config.quantum_threads);
    println!("   SIMD level: {}", config.simd_level);
    println!("   Risk tolerance: {:.1}%", config.risk_tolerance * 100.0);
    println!("   Aggression factor: {:.1}x", config.aggression_factor);
    println!("   Quantum coherence: {}", config.quantum_coherence);
    println!();
    
    let system = ParasiticTradingSystem::new(config);
    
    // Demonstrate system activation
    println!("🚀 Activating Parasitic Trading System...");
    system.activate().await?;
    println!("✅ System activated successfully!");
    println!();
    
    // Show initial system status
    let status = system.get_status().await;
    println!("📊 System Status:");
    println!("{}", serde_json::to_string_pretty(&status)?);
    println!();
    
    // Let the system run and hunt for opportunities
    println!("🕸️ Cuckoo strategies now hunting for hosts...");
    for i in 1..=10 {
        sleep(Duration::from_millis(500)).await;
        
        let metrics = system.get_performance_metrics().await;
        
        println!("📈 Cycle {} - Performance Metrics:", i);
        println!("   Total profit: ${:.2}", metrics.total_profit);
        println!("   Hosts identified: {}", metrics.total_hosts_identified);
        println!("   Successful parasitisms: {}", metrics.total_successful_parasitisms);
        println!("   Failed parasitisms: {}", metrics.total_failed_parasitisms);
        println!("   Positions placed: {}", metrics.total_positions_placed);
        println!("   Competitors eliminated: {}", metrics.total_competitors_eliminated);
        println!("   Win rate: {:.1}%", metrics.overall_win_rate * 100.0);
        
        if i % 3 == 0 {
            println!("   🥚 Checking for egg hatching...");
        }
        
        println!();
    }
    
    // Demonstrate adding additional strategies
    println!("➕ Attempting to add additional Cuckoo strategy...");
    match system.add_strategy(ParasiteType::Cuckoo).await {
        Ok(()) => println!("✅ Additional strategy added successfully!"),
        Err(e) => println!("⚠️ Could not add strategy: {}", e),
    }
    println!();
    
    // Show final performance results
    println!("📊 Final Performance Report:");
    let final_metrics = system.get_performance_metrics().await;
    
    println!("═══════════════════════════════════════════════════════");
    println!("🎯 PARASITISM EFFECTIVENESS:");
    println!("   Total Profit: ${:.2}", final_metrics.total_profit);
    println!("   Win Rate: {:.1}%", final_metrics.overall_win_rate * 100.0);
    println!("   Hosts Exploited: {}", final_metrics.total_hosts_identified);
    println!("   Successful Parasitisms: {}", final_metrics.total_successful_parasitisms);
    println!("   Failed Attempts: {}", final_metrics.total_failed_parasitisms);
    println!();
    
    println!("🔥 AGGRESSIVE BEHAVIOR:");
    println!("   Positions Injected: {}", final_metrics.total_positions_placed);
    println!("   Competitors Eliminated: {}", final_metrics.total_competitors_eliminated);
    println!();
    
    let efficiency = if final_metrics.total_positions_placed > 0 {
        final_metrics.total_successful_parasitisms as f64 / final_metrics.total_positions_placed as f64
    } else {
        0.0
    };
    
    println!("📈 EFFICIENCY METRICS:");
    println!("   Parasitism Efficiency: {:.1}%", efficiency * 100.0);
    
    if final_metrics.total_profit > 0.0 {
        println!("   Profit per Host: ${:.2}", final_metrics.total_profit / final_metrics.total_hosts_identified.max(1) as f64);
    }
    
    println!("═══════════════════════════════════════════════════════");
    println!();
    
    // Demonstrate different parasite types (even though only Cuckoo is implemented)
    println!("🧬 Available Parasite Types:");
    let parasite_types = [ParasiteType::Cuckoo, ParasiteType::Wasp, ParasiteType::Cordyceps, ParasiteType::Lamprey];
    
    for parasite_type in &parasite_types {
        println!("   {:?}:", parasite_type);
        println!("     Description: {}", parasite_type.description());
        println!("     Efficiency: {:.1}%", parasite_type.efficiency_rating() * 100.0);
        println!("     Risk Level: {:.1}%", parasite_type.risk_level() * 100.0);
        
        match create_parasite_strategy(*parasite_type).await {
            Ok(_) => println!("     Status: ✅ Available"),
            Err(e) => println!("     Status: ⏳ {}", e),
        }
        println!();
    }
    
    // Test system under brief load
    println!("⚡ Testing system under high-frequency load...");
    let start = std::time::Instant::now();
    let mut operation_count = 0;
    
    while start.elapsed() < Duration::from_secs(2) {
        let _ = system.get_status().await;
        let _ = system.get_performance_metrics().await;
        operation_count += 1;
        
        if operation_count % 100 == 0 {
            tokio::task::yield_now().await;
        }
    }
    
    let ops_per_sec = operation_count as f64 / start.elapsed().as_secs_f64();
    println!("   Operations completed: {}", operation_count);
    println!("   Operations per second: {:.0}", ops_per_sec);
    println!("   ✅ System performed well under load!");
    println!();
    
    // Graceful shutdown
    println!("🛑 Deactivating Parasitic Trading System...");
    system.deactivate().await?;
    println!("✅ System deactivated successfully!");
    
    // Final status check
    let final_status = system.get_status().await;
    println!("📊 Final System Status: {}", final_status["status"]);
    println!("   Active strategies: {}", final_status["active_strategies"]);
    
    println!();
    println!("🎉 Cuckoo Parasitism Demo Completed Successfully!");
    println!("   The Cuckoo strategy demonstrated ruthless efficiency");
    println!("   in identifying, exploiting, and dominating trading opportunities.");
    
    Ok(())
}