//! Parasitic Trading System Performance Demo
//! 
//! This example demonstrates the ultra-high performance capabilities
//! of the parasitic trading system, targeting sub-microsecond decision making.

use parasitic::{
    ParasiticTradingSystem, ParasiticConfig, create_optimized_system,
    TradingPattern, ParasiticOrganism, HostCandidate,
    SimdPatternMatcher, SimdFitnessCalculator, SimdHostSelector,
    ParasiticSimdFeatures,
};
use std::time::{Instant, Duration};
use std::thread;
use std::sync::Arc;

fn main() {
    println!("🧬 Parasitic Trading System Performance Demo");
    println!("============================================");
    
    // Detect SIMD capabilities
    let features = ParasiticSimdFeatures::detect();
    println!("🚀 SIMD Features Detected:");
    println!("   SSE4.2: {}", features.has_sse42);
    println!("   AVX2: {}", features.has_avx2);
    println!("   AVX-512F: {}", features.has_avx512f);
    println!("   AVX-512BW: {}", features.has_avx512bw);
    println!("   FMA: {}", features.has_fma);
    println!("   POPCNT: {}", features.has_popcnt);
    println!("   BMI2: {}", features.has_bmi2);
    println!();
    
    // Performance demonstration
    demo_pattern_matching();
    demo_fitness_calculation();
    demo_host_selection();
    demo_complete_decision_cycle();
    demo_concurrent_operations();
    demo_memory_efficiency();
    
    println!("✅ All performance demos completed successfully!");
}

/// Demonstrate pattern matching performance
fn demo_pattern_matching() {
    println!("📊 Pattern Matching Performance Demo");
    println!("-----------------------------------");
    
    let matcher = SimdPatternMatcher::new();
    
    // Generate test patterns
    let target = create_test_pattern(0);
    let patterns: Vec<TradingPattern> = (1..1025).map(create_test_pattern).collect();
    
    println!("   Testing with {} patterns", patterns.len());
    
    // Warmup
    for _ in 0..100 {
        unsafe {
            let _ = matcher.find_similar_patterns(&target, &patterns, 0.7);
        }
    }
    
    // Performance measurement
    let iterations = 1000;
    let start = Instant::now();
    
    for _ in 0..iterations {
        unsafe {
            let results = matcher.find_similar_patterns(&target, &patterns, 0.7);
            // Prevent optimization
            std::hint::black_box(results);
        }
    }
    
    let duration = start.elapsed();
    let avg_ns = duration.as_nanos() / iterations as u128;
    
    println!("   ⚡ Average time: {}ns (Target: <100ns)", avg_ns);
    println!("   📈 Throughput: {:.2}M patterns/sec", 
             (patterns.len() as f64 * iterations as f64) / duration.as_secs_f64() / 1_000_000.0);
    
    if avg_ns < 100 {
        println!("   ✅ TARGET ACHIEVED!");
    } else {
        println!("   ⚠️  Target missed by {}ns", avg_ns - 100);
    }
    println!();
}

/// Demonstrate fitness calculation performance
fn demo_fitness_calculation() {
    println!("🧬 Fitness Calculation Performance Demo");
    println!("-------------------------------------");
    
    let calculator = SimdFitnessCalculator::new();
    let market_conditions = [1.0, 0.8, 1.2, 0.9, 1.1, 0.95, 1.05, 0.85];
    
    // Test with 16 organisms (optimal SIMD batch size)
    let mut organisms: Vec<ParasiticOrganism> = (0..16).map(create_test_organism).collect();
    
    println!("   Testing with {} organisms", organisms.len());
    
    // Warmup
    for _ in 0..100 {
        unsafe {
            calculator.evaluate_batch_fitness(&mut organisms, &market_conditions);
        }
    }
    
    // Performance measurement
    let iterations = 2000;
    let start = Instant::now();
    
    for _ in 0..iterations {
        unsafe {
            calculator.evaluate_batch_fitness(&mut organisms, &market_conditions);
        }
        // Prevent optimization
        std::hint::black_box(&organisms);
    }
    
    let duration = start.elapsed();
    let avg_ns = duration.as_nanos() / iterations as u128;
    
    println!("   ⚡ Average time: {}ns (Target: <50ns)", avg_ns);
    println!("   📈 Throughput: {:.2}M evaluations/sec",
             (organisms.len() as f64 * iterations as f64) / duration.as_secs_f64() / 1_000_000.0);
    
    if avg_ns < 50 {
        println!("   ✅ TARGET ACHIEVED!");
    } else {
        println!("   ⚠️  Target missed by {}ns", avg_ns - 50);
    }
    println!();
}

/// Demonstrate host selection performance
fn demo_host_selection() {
    println!("🏠 Host Selection Performance Demo");
    println!("--------------------------------");
    
    let selector = SimdHostSelector::new();
    let organism = create_test_organism(0);
    let mut hosts: Vec<HostCandidate> = (0..64).map(create_test_host).collect();
    
    println!("   Testing with {} host candidates", hosts.len());
    
    // Warmup
    for _ in 0..100 {
        unsafe {
            let _ = selector.select_best_hosts(&mut hosts, &organism, 5);
        }
    }
    
    // Performance measurement
    let iterations = 2000;
    let start = Instant::now();
    
    for _ in 0..iterations {
        unsafe {
            let results = selector.select_best_hosts(&mut hosts, &organism, 5);
            std::hint::black_box(results);
        }
    }
    
    let duration = start.elapsed();
    let avg_ns = duration.as_nanos() / iterations as u128;
    
    println!("   ⚡ Average time: {}ns (Target: <30ns)", avg_ns);
    println!("   📈 Throughput: {:.2}M selections/sec",
             (iterations as f64) / duration.as_secs_f64() / 1_000_000.0);
    
    if avg_ns < 30 {
        println!("   ✅ TARGET ACHIEVED!");
    } else {
        println!("   ⚠️  Target missed by {}ns", avg_ns - 30);
    }
    println!();
}

/// Demonstrate complete decision cycle performance  
fn demo_complete_decision_cycle() {
    println!("🔄 Complete Decision Cycle Demo");
    println!("-----------------------------");
    
    let config = ParasiticConfig {
        max_organisms: 100,
        max_hosts: 50,
        max_patterns: 500,
        ..ParasiticConfig::default()
    };
    
    let mut system = create_optimized_system(config);
    
    // Populate system with test data
    for i in 0..50 {
        system.add_organism(create_test_organism(i));
        system.add_host(create_test_host(i as u32));
    }
    
    for i in 0..200 {
        system.add_pattern(create_test_pattern(i));
    }
    
    let market_conditions = [1.0, 0.8, 1.2, 0.9, 1.1, 0.95, 1.05, 0.85];
    
    println!("   System populated with:");
    println!("   - {} organisms", 50);
    println!("   - {} hosts", 50);
    println!("   - {} patterns", 200);
    
    // Warmup
    for _ in 0..50 {
        let _ = system.execute_decision_cycle(&market_conditions);
    }
    
    // Performance measurement
    let iterations = 1000;
    let start = Instant::now();
    
    for _ in 0..iterations {
        let results = system.execute_decision_cycle(&market_conditions);
        std::hint::black_box(results);
    }
    
    let duration = start.elapsed();
    let avg_ns = duration.as_nanos() / iterations as u128;
    let avg_us = avg_ns as f64 / 1000.0;
    
    println!("   ⚡ Average time: {:.1}μs (Target: <1μs)", avg_us);
    println!("   📈 Decision rate: {:.2}M decisions/sec",
             (iterations as f64) / duration.as_secs_f64() / 1_000_000.0);
    
    if avg_us < 1.0 {
        println!("   ✅ SUB-MICROSECOND TARGET ACHIEVED!");
    } else {
        println!("   ⚠️  Target missed by {:.1}μs", avg_us - 1.0);
    }
    
    let metrics = system.get_metrics();
    println!("   📊 System metrics:");
    println!("      Average fitness: {:.3}", metrics.average_fitness);
    println!("      Best fitness: {:.3}", metrics.best_fitness);
    println!();
}

/// Demonstrate concurrent operations
fn demo_concurrent_operations() {
    println!("🔄 Concurrent Operations Demo");
    println!("---------------------------");
    
    let config = ParasiticConfig::default();
    let system = Arc::new(std::sync::Mutex::new(create_optimized_system(config)));
    
    // Spawn multiple threads to simulate concurrent trading
    let mut handles = Vec::new();
    let num_threads = 4;
    let operations_per_thread = 1000;
    
    println!("   Spawning {} threads with {} operations each", num_threads, operations_per_thread);
    
    let start = Instant::now();
    
    for thread_id in 0..num_threads {
        let system_clone = system.clone();
        
        let handle = thread::spawn(move || {
            let market_conditions = [
                1.0 + (thread_id as f32 * 0.1), 
                0.8, 1.2, 0.9, 1.1, 0.95, 1.05, 0.85
            ];
            
            let mut decisions_made = 0;
            
            for i in 0..operations_per_thread {
                // Add some test data periodically
                if i % 100 == 0 {
                    let mut sys = system_clone.lock().unwrap();
                    sys.add_organism(create_test_organism(i + thread_id * 1000));
                    sys.add_host(create_test_host((i + thread_id * 1000) as u32));
                    sys.add_pattern(create_test_pattern(i + thread_id * 1000));
                }
                
                // Execute decision cycle
                {
                    let mut sys = system_clone.lock().unwrap();
                    let _ = sys.execute_decision_cycle(&market_conditions);
                    decisions_made += 1;
                }
                
                // Small delay to simulate realistic trading intervals
                thread::sleep(Duration::from_nanos(100));
            }
            
            decisions_made
        });
        
        handles.push(handle);
    }
    
    // Wait for all threads
    let mut total_decisions = 0;
    for handle in handles {
        total_decisions += handle.join().unwrap();
    }
    
    let duration = start.elapsed();
    
    println!("   ✅ Completed {} total decisions", total_decisions);
    println!("   ⚡ Average throughput: {:.0} decisions/sec",
             total_decisions as f64 / duration.as_secs_f64());
    println!("   🕒 Total time: {:.2}s", duration.as_secs_f64());
    println!();
}

/// Demonstrate memory efficiency
fn demo_memory_efficiency() {
    println!("💾 Memory Efficiency Demo");
    println!("-----------------------");
    
    let config = ParasiticConfig {
        max_organisms: 1000,
        max_hosts: 500,
        max_patterns: 5000,
        ..ParasiticConfig::default()
    };
    
    let system = create_optimized_system(config);
    let initial_metrics = system.get_metrics();
    
    println!("   Initial system state:");
    println!("   - Organism capacity: {}", config.max_organisms);
    println!("   - Host capacity: {}", config.max_hosts);
    println!("   - Pattern capacity: {}", config.max_patterns);
    
    // Calculate memory footprint estimates
    let organism_size = std::mem::size_of::<ParasiticOrganism>();
    let host_size = std::mem::size_of::<HostCandidate>();
    let pattern_size = std::mem::size_of::<TradingPattern>();
    
    let estimated_memory_mb = (
        organism_size * config.max_organisms +
        host_size * config.max_hosts +
        pattern_size * config.max_patterns
    ) as f64 / (1024.0 * 1024.0);
    
    println!("   📊 Memory usage estimate:");
    println!("   - Per organism: {} bytes", organism_size);
    println!("   - Per host: {} bytes", host_size);
    println!("   - Per pattern: {} bytes", pattern_size);
    println!("   - Total estimated: {:.2} MB", estimated_memory_mb);
    
    // Verify cache alignment
    println!("   🔧 Cache alignment verification:");
    println!("   - ParasiticOrganism aligned to: {} bytes", std::mem::align_of::<ParasiticOrganism>());
    println!("   - HostCandidate aligned to: {} bytes", std::mem::align_of::<HostCandidate>());
    println!("   - TradingPattern aligned to: {} bytes", std::mem::align_of::<TradingPattern>());
    println!();
    
    drop(system); // Explicit cleanup
    println!("   ✅ Memory efficiency verification completed");
    println!();
}

/// Helper function to create test trading pattern
fn create_test_pattern(id: u64) -> TradingPattern {
    let mut pattern = TradingPattern::new(id as u32);
    
    // Realistic price movement simulation
    let base_price = 100.0 + (id as f32 * 0.1) % 50.0;
    for i in 0..8 {
        pattern.price_history[i] = base_price + (i as f32 * 0.1) + ((id * 7 + i as u64) % 100) as f32 * 0.01;
        pattern.volume_history[i] = 1000.0 + ((id * 11 + i as u64) % 5000) as f32;
    }
    
    pattern.volatility = 0.05 + ((id * 13) % 100) as f32 * 0.001;
    pattern.momentum = -0.1 + ((id * 17) % 200) as f32 * 0.001;
    pattern.rsi = 20.0 + ((id * 19) % 60) as f32;
    pattern.macd = -2.0 + ((id * 23) % 400) as f32 * 0.01;
    pattern.timestamp = id * 1_000_000; // Microsecond timestamps
    
    pattern
}

/// Helper function to create test organism
fn create_test_organism(id: u64) -> ParasiticOrganism {
    let mut organism = ParasiticOrganism::new(id);
    
    // Initialize strategy weights with pseudo-random values
    for i in 0..16 {
        organism.strategy_weights[i] = -1.0 + ((id * 29 + i as u64) % 200) as f32 * 0.01;
    }
    
    // Initialize performance history
    for i in 0..8 {
        organism.performance_history[i] = -0.1 + ((id * 31 + i as u64) % 200) as f32 * 0.001;
    }
    
    // Initialize risk metrics
    for i in 0..4 {
        organism.risk_metrics[i] = ((id * 37 + i as u64) % 100) as f32 * 0.001;
    }
    
    organism.age = ((id * 41) % 500) as u32;
    organism.mutations = ((id * 43) % 50) as u32;
    organism.host_preference = ((id * 47) % 10) as u32;
    
    organism
}

/// Helper function to create test host candidate
fn create_test_host(id: u32) -> HostCandidate {
    let mut host = HostCandidate::new(id);
    
    // Initialize liquidity metrics
    for i in 0..4 {
        host.liquidity_metrics[i] = 500.0 + ((id * 53 + i as u32) % 2000) as f32;
    }
    
    // Initialize spread history
    for i in 0..8 {
        host.spread_history[i] = 0.0005 + ((id * 59 + i as u32) % 50) as f32 * 0.00001;
    }
    
    // Initialize volume profile
    for i in 0..8 {
        host.volume_profile[i] = 5000.0 + ((id * 61 + i as u32) % 20000) as f32;
    }
    
    host.stability_score = 0.3 + ((id * 67) % 70) as f32 * 0.01;
    host.parasitism_resistance = ((id * 71) % 30) as f32 * 0.01;
    host.last_update = id as u64 * 1_000_000;
    
    host
}