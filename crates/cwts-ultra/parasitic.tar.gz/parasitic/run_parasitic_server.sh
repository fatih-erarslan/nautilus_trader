#!/bin/bash

# Run the CWTS Ultra Parasitic MCP Server
# This starts the biomimetic trading organism system

echo "🐛 Starting CWTS Ultra Parasitic System..."
echo "================================================"
echo "🧬 Organisms: Cuckoo, Wasp, Virus, Bacteria"
echo "🎯 Target: Ultra-low latency parasitic trading"
echo "⚡ Performance: <100μs decision making"
echo "================================================"

# Set environment variables
export RUST_LOG=info
export PARASITIC_PORT=3001
export PARASITIC_MAX_CONNECTIONS=100
export PARASITIC_ENABLE_SIMD=true
export PARASITIC_ENABLE_EVOLUTION=true

# Build if needed
if [ ! -f "target/release/parasitic" ]; then
    echo "📦 Building parasitic system..."
    cargo build --release --features simd
fi

# Run the MCP server
echo "🚀 Starting MCP server on port 3001..."
cargo run --release --example mcp_server_standalone 2>&1 | tee parasitic.log &
SERVER_PID=$!

echo "✅ Parasitic MCP server started (PID: $SERVER_PID)"
echo ""
echo "📊 Available MCP Resources:"
echo "  - parasitic://organisms       - List parasitic organisms"
echo "  - parasitic://pairs/infected  - Currently infected pairs"
echo "  - parasitic://evolution/status - Evolution metrics"
echo ""
echo "🔧 Available MCP Tools:"
echo "  - parasitic_select  - Select organism strategy"
echo "  - parasitic_infect  - Infect trading pair"
echo "  - parasitic_evolve  - Trigger evolution"
echo "  - parasitic_analyze - Analyze vulnerability"
echo ""
echo "🔌 WebSocket endpoint: ws://localhost:3001"
echo ""
echo "📝 Logs: tail -f parasitic.log"
echo "🛑 Stop: kill $SERVER_PID"
echo ""
echo "🦟 The parasites are ready to hunt..."

# Keep script running
wait $SERVER_PID