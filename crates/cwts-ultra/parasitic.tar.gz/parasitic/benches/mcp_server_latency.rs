use criterion::{black_box, criterion_group, criterion_main, Criterion};
use tokio::runtime::Runtime;
use cwts_parasitic::{ParasiticEngineInner, ParasiticConfig, ParasiticMCPServer};

fn bench_mcp_server_startup(c: &mut Criterion) {
    let rt = Runtime::new().unwrap();
    
    c.bench_function("mcp_server_startup", |b| {
        b.iter(|| {
            rt.block_on(async {
                let config = ParasiticConfig::default();
                let server = black_box(ParasiticMCPServer::new(&config.mcp_config).await.unwrap());
                drop(server);
            })
        })
    });
}

fn bench_infection_calculation(c: &mut Criterion) {
    let rt = Runtime::new().unwrap();
    let engine = rt.block_on(async {
        let config = ParasiticConfig::default();
        let engine = ParasiticEngineInner::new(config);
        engine.initialize().await.unwrap();
        engine
    });
    
    let organism_id = engine.organisms.iter().next().unwrap().key().clone();
    
    c.bench_function("pair_infection", |b| {
        b.iter(|| {
            rt.block_on(async {
                let result = black_box(engine.infect_pair("BTCUSD".to_string(), organism_id).await);
                result
            })
        })
    });
}

criterion_group!(benches, bench_mcp_server_startup, bench_infection_calculation);
criterion_main!(benches);