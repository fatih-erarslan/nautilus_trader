use criterion::{black_box, criterion_group, criterion_main, Criterion};
use tokio::runtime::Runtime;
use cwts_parasitic::{ParasiticEngineInner, ParasiticConfig};

fn bench_organism_evolution(c: &mut Criterion) {
    let rt = Runtime::new().unwrap();
    let engine = rt.block_on(async {
        let config = ParasiticConfig::default();
        let engine = ParasiticEngineInner::new(config);
        engine.initialize().await.unwrap();
        engine
    });
    
    c.bench_function("evolution_cycle", |b| {
        b.iter(|| {
            rt.block_on(async {
                let result = black_box(
                    engine.evolution_engine.evolve_organisms(&engine.organisms).await
                );
                result
            })
        })
    });
}

criterion_group!(benches, bench_organism_evolution);
criterion_main!(benches);