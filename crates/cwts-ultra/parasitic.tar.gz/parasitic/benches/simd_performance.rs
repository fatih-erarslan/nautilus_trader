//! High-Performance Benchmarks for Parasitic SIMD Operations
//! 
//! This benchmark suite validates sub-microsecond performance targets:
//! - Pattern matching: <100ns for 1024 patterns
//! - Fitness evaluation: <50ns for batch of 16 organisms  
//! - Host selection: <30ns for scoring 64 hosts
//! - Complete decision cycle: <1μs total

use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion};
use std::time::Duration;

// Import our parasitic system components
use parasitic::simd_ops::{
    SimdPatternMatcher, SimdFitnessCalculator, SimdHostSelector,
    TradingPattern, ParasiticOrganism, HostCandidate,
    lockfree_collections::LockFreeRingBuffer,
};
use parasitic::{ParasiticTradingSystem, ParasiticConfig, create_optimized_system};

/// Generate test trading patterns for benchmarking
fn generate_test_patterns(count: usize) -> Vec<TradingPattern> {
    (0..count).map(|i| {
        let mut pattern = TradingPattern::new(i as u32);
        
        // Fill with realistic test data
        for j in 0..8 {
            pattern.price_history[j] = 100.0 + (i as f32 * 0.1) + (j as f32 * 0.01);
            pattern.volume_history[j] = 1000.0 + (i as f32 * 10.0) + (j as f32);
        }
        
        pattern.volatility = 0.1 + (i as f32 * 0.001);
        pattern.momentum = -0.05 + (i as f32 * 0.0001);
        pattern.rsi = 30.0 + (i as f32 * 0.04);
        pattern.macd = -1.0 + (i as f32 * 0.002);
        pattern.timestamp = i as u64 * 1_000_000; // Microsecond timestamps
        
        pattern
    }).collect()
}

/// Generate test organisms for fitness benchmarking
fn generate_test_organisms(count: usize) -> Vec<ParasiticOrganism> {
    (0..count).map(|i| {
        let mut organism = ParasiticOrganism::new(i as u64);
        
        // Fill strategy weights with test data
        for j in 0..16 {
            organism.strategy_weights[j] = -1.0 + (j as f32 * 0.125) + (i as f32 * 0.001);
        }
        
        // Fill performance history
        for j in 0..8 {
            organism.performance_history[j] = 0.01 + (j as f32 * 0.001) + (i as f32 * 0.0001);
        }
        
        // Fill risk metrics
        for j in 0..4 {
            organism.risk_metrics[j] = 0.05 + (j as f32 * 0.01) + (i as f32 * 0.0001);
        }
        
        organism.age = (i % 1000) as u32;
        organism.mutations = (i % 100) as u32;
        organism.host_preference = (i % 10) as u32;
        
        organism
    }).collect()
}

/// Generate test host candidates for selection benchmarking
fn generate_test_hosts(count: usize) -> Vec<HostCandidate> {
    (0..count).map(|i| {
        let mut host = HostCandidate::new(i as u32);
        
        // Fill liquidity metrics
        for j in 0..4 {
            host.liquidity_metrics[j] = 1000.0 + (i as f32 * 10.0) + (j as f32 * 100.0);
        }
        
        // Fill spread history
        for j in 0..8 {
            host.spread_history[j] = 0.001 + (i as f32 * 0.0001) + (j as f32 * 0.00001);
        }
        
        // Fill volume profile
        for j in 0..8 {
            host.volume_profile[j] = 10000.0 + (i as f32 * 100.0) + (j as f32 * 10.0);
        }
        
        host.stability_score = 0.5 + (i as f32 * 0.001);
        host.parasitism_resistance = 0.1 + (i as f32 * 0.001);
        host.last_update = i as u64 * 1_000_000;
        
        host
    }).collect()
}

/// Benchmark pattern matching performance
fn bench_pattern_matching(c: &mut Criterion) {
    let matcher = SimdPatternMatcher::new();
    let target = generate_test_patterns(1)[0];
    
    // Test different pattern database sizes
    let sizes = [64, 128, 256, 512, 1024, 2048];
    
    let mut group = c.benchmark_group("pattern_matching");
    group.measurement_time(Duration::from_secs(10));
    group.sample_size(1000);
    
    for &size in &sizes {
        let patterns = generate_test_patterns(size);
        
        group.bench_with_input(
            BenchmarkId::new("simd_pattern_match", size),
            &size,
            |b, _| {
                b.iter(|| {
                    unsafe {
                        matcher.find_similar_patterns(
                            black_box(&target),
                            black_box(&patterns),
                            black_box(0.5),
                        )
                    }
                });
            }
        );
    }
    
    group.finish();
}

/// Benchmark fitness calculation performance
fn bench_fitness_calculation(c: &mut Criterion) {
    let calculator = SimdFitnessCalculator::new();
    let market_conditions = [1.0, 0.8, 1.2, 0.9, 1.1, 0.95, 1.05, 0.85];
    
    // Test different organism batch sizes
    let sizes = [4, 8, 16, 32, 64, 128];
    
    let mut group = c.benchmark_group("fitness_calculation");
    group.measurement_time(Duration::from_secs(10));
    group.sample_size(2000);
    
    for &size in &sizes {
        let mut organisms = generate_test_organisms(size);
        
        group.bench_with_input(
            BenchmarkId::new("simd_fitness_batch", size),
            &size,
            |b, _| {
                b.iter(|| {
                    unsafe {
                        calculator.evaluate_batch_fitness(
                            black_box(&mut organisms),
                            black_box(&market_conditions),
                        );
                    }
                });
            }
        );
    }
    
    group.finish();
}

/// Benchmark host selection performance
fn bench_host_selection(c: &mut Criterion) {
    let selector = SimdHostSelector::new();
    let organism = generate_test_organisms(1)[0];
    
    // Test different host pool sizes
    let sizes = [16, 32, 64, 128, 256];
    
    let mut group = c.benchmark_group("host_selection");
    group.measurement_time(Duration::from_secs(10));
    group.sample_size(2000);
    
    for &size in &sizes {
        let mut hosts = generate_test_hosts(size);
        
        group.bench_with_input(
            BenchmarkId::new("simd_host_select", size),
            &size,
            |b, _| {
                b.iter(|| {
                    unsafe {
                        selector.select_best_hosts(
                            black_box(&mut hosts),
                            black_box(&organism),
                            black_box(5),
                        )
                    }
                });
            }
        );
    }
    
    group.finish();
}

/// Benchmark complete decision cycle performance
fn bench_decision_cycle(c: &mut Criterion) {
    let config = ParasiticConfig {
        max_organisms: 100,
        max_hosts: 50,
        max_patterns: 500,
        ..ParasiticConfig::default()
    };
    
    let mut system = create_optimized_system(config);
    
    // Populate system with test data
    let organisms = generate_test_organisms(50);
    let hosts = generate_test_hosts(25);
    let patterns = generate_test_patterns(200);
    
    for organism in organisms {
        system.add_organism(organism);
    }
    
    for host in hosts {
        system.add_host(host);
    }
    
    for pattern in patterns {
        system.add_pattern(pattern);
    }
    
    let market_conditions = [1.0, 0.8, 1.2, 0.9, 1.1, 0.95, 1.05, 0.85];
    
    let mut group = c.benchmark_group("decision_cycle");
    group.measurement_time(Duration::from_secs(15));
    group.sample_size(500);
    
    // Target: <1 microsecond complete decision cycle
    group.bench_function("complete_cycle", |b| {
        b.iter(|| {
            system.execute_decision_cycle(black_box(&market_conditions))
        });
    });
    
    group.finish();
}

/// Benchmark lock-free data structures
fn bench_lockfree_structures(c: &mut Criterion) {
    let buffer: LockFreeRingBuffer<u64> = LockFreeRingBuffer::new(1024);
    
    let mut group = c.benchmark_group("lockfree_structures");
    group.measurement_time(Duration::from_secs(10));
    group.sample_size(5000);
    
    // Benchmark ring buffer operations
    group.bench_function("ring_buffer_push", |b| {
        let mut counter = 0u64;
        b.iter(|| {
            let item = Box::into_raw(Box::new(counter));
            counter += 1;
            buffer.push(black_box(item))
        });
    });
    
    group.bench_function("ring_buffer_pop", |b| {
        // Pre-fill buffer
        for i in 0..512 {
            let item = Box::into_raw(Box::new(i));
            buffer.push(item);
        }
        
        b.iter(|| {
            buffer.pop()
        });
    });
    
    group.finish();
}

/// Benchmark memory allocation patterns
fn bench_memory_patterns(c: &mut Criterion) {
    let mut group = c.benchmark_group("memory_patterns");
    group.measurement_time(Duration::from_secs(8));
    group.sample_size(1000);
    
    // Test cache-friendly vs cache-unfriendly access patterns
    let data: Vec<f32> = (0..4096).map(|i| i as f32).collect();
    
    group.bench_function("sequential_access", |b| {
        b.iter(|| {
            let mut sum = 0.0f32;
            for &value in black_box(&data) {
                sum += value;
            }
            sum
        });
    });
    
    group.bench_function("strided_access", |b| {
        b.iter(|| {
            let mut sum = 0.0f32;
            for i in (0..black_box(&data).len()).step_by(16) {
                sum += data[i];
            }
            sum
        });
    });
    
    group.finish();
}

/// Comprehensive latency analysis
fn bench_latency_analysis(c: &mut Criterion) {
    let mut group = c.benchmark_group("latency_analysis");
    group.measurement_time(Duration::from_secs(20));
    group.sample_size(10000);
    
    // Individual operation latency targets
    let patterns = generate_test_patterns(1024);
    let target = &patterns[0];
    let matcher = SimdPatternMatcher::new();
    
    // Target: <100ns for pattern matching 1024 patterns
    group.bench_function("pattern_match_1024_target", |b| {
        b.iter(|| {
            unsafe {
                matcher.find_similar_patterns(
                    black_box(target),
                    black_box(&patterns),
                    black_box(0.8),
                )
            }
        });
    });
    
    let calculator = SimdFitnessCalculator::new();
    let mut organisms = generate_test_organisms(16);
    let market_conditions = [1.0; 8];
    
    // Target: <50ns for fitness evaluation of 16 organisms
    group.bench_function("fitness_16_organisms_target", |b| {
        b.iter(|| {
            unsafe {
                calculator.evaluate_batch_fitness(
                    black_box(&mut organisms),
                    black_box(&market_conditions),
                );
            }
        });
    });
    
    let selector = SimdHostSelector::new();
    let mut hosts = generate_test_hosts(64);
    let organism = &organisms[0];
    
    // Target: <30ns for host selection from 64 candidates
    group.bench_function("host_select_64_target", |b| {
        b.iter(|| {
            unsafe {
                selector.select_best_hosts(
                    black_box(&mut hosts),
                    black_box(organism),
                    black_box(5),
                )
            }
        });
    });
    
    group.finish();
}

/// Performance regression testing
fn bench_regression_tests(c: &mut Criterion) {
    let mut group = c.benchmark_group("regression_tests");
    group.measurement_time(Duration::from_secs(5));
    group.sample_size(100);
    
    // Ensure performance doesn't regress below acceptable thresholds
    let config = ParasiticConfig::default();
    let mut system = create_optimized_system(config);
    
    // Add representative load
    for i in 0..50 {
        system.add_organism(ParasiticOrganism::new(i));
        system.add_host(HostCandidate::new(i as u32));
    }
    
    for i in 0..100 {
        system.add_pattern(TradingPattern::new(i as u32));
    }
    
    let market_conditions = [1.0; 8];
    
    group.bench_function("system_stress_test", |b| {
        b.iter(|| {
            for _ in 0..10 {
                system.execute_decision_cycle(black_box(&market_conditions));
            }
        });
    });
    
    group.finish();
}

/// SIMD feature detection benchmark
fn bench_simd_features(c: &mut Criterion) {
    use parasitic::simd_ops::ParasiticSimdFeatures;
    
    let mut group = c.benchmark_group("simd_features");
    group.measurement_time(Duration::from_secs(5));
    group.sample_size(10000);
    
    group.bench_function("feature_detection", |b| {
        b.iter(|| {
            ParasiticSimdFeatures::detect()
        });
    });
    
    group.finish();
}

criterion_group!(
    benches,
    bench_pattern_matching,
    bench_fitness_calculation,
    bench_host_selection,
    bench_decision_cycle,
    bench_lockfree_structures,
    bench_memory_patterns,
    bench_latency_analysis,
    bench_regression_tests,
    bench_simd_features,
);

criterion_main!(benches);